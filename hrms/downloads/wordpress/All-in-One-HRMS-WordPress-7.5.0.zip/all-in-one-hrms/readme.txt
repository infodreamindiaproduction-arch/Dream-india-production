All in One HRMS — WordPress theme 7.5.0

INSTALL
1. In WordPress, open Appearance > Themes > Add New > Upload Theme.
2. Upload All-in-One-HRMS-WordPress-7.5.0.zip directly. Do not unzip it first.
3. Click Install Now, then Activate.
4. Open your website and click Portal Login. Use your own WordPress Administrator
   username/password. This account is the HRMS Super Admin.
5. The portal can also be opened at /?hrms_portal=1 on your website.
6. Set the company identity, add companies/company Admins if needed, then onboard
   employees. Onboarding can create the employee's user ID/password at the same time.

Company Admin creates HR/employee logins. HR works only in its assigned company;
employees see their own private attendance, requests and payslips.

Settings: add branch names and Facebook, Instagram, X, Threads, LinkedIn,
WhatsApp (https://wa.me/...), Snapchat and website links. Onboarding Job selects
the branch/work location. Brand settings changes support name/email/phone/website.
Print opens the browser/device print dialog to select an available printer.

REQUIREMENTS
WordPress 6.0 or newer, PHP 8.1 or newer, a working WordPress database and HTTPS.
Clean installation verified on WordPress 6.8.3 / PHP 8.3.
No separate HRMS database import, Node.js server or paid plugin is required.
Existing WordPress/customer data is not included in this archive.

The theme creates its company tables/roles automatically. It starts with empty
employee records and never installs the public preview's sample accounts.
Back up an existing WordPress website before replacing its active theme.

Enquiries use WordPress mail to productiondreamindia@gmail.com. Configure your
hosting mail/SMTP transport for actual delivery; installing a theme cannot
configure an external email account. PDF/CSV/Excel exports run in the portal.
Payment collection, bank payout and statutory filing integrations are not enabled.

Theme licence: GPL-2.0-or-later. Bundled font/library notices are included.


EMPLOYEE LOGINS AFTER ONBOARDING
Open Employee Logins & Progress below Onboarding. Select a pending employee,
set a Login ID (or use staff email), password and confirmation. The page shows
created/pending logins and profile completion, with search, CSV and A4 print.
The account is linked to the existing employee; a duplicate profile is not made.
Only Company Admin/Super Admin can create login credentials. HR cannot issue them.

SAAS CLIENTS & LICENSES — SUPER ADMIN ONLY
Create a company and its own administrator together. Set plan, monthly/quarterly/
annual cycle, fee, staff limit and valid-through date (IST). The fee is a manual
record; this does not collect payments. Suspended/expired licenses block private
HR access for Company Admin, HR and employees. Super Admin retains recovery access.
Blank expiry has no end date. Old companies without a license remain accessible;
assign a license explicitly from SaaS Clients & Licenses to enforce limits.

Company Admin/HR headers display the active company name. Employee headers display
the employee's full name. Settings > Upload / change company logo opens the payslip
logo upload. Finalised payslips retain the logo saved when payroll was finalised.
