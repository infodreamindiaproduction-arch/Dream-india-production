/* Offline English/Hindi interface labels. Employee-entered records are not translated. */
(function(){'use strict';
const labels={
"Mark employee attendance":"कर्मचारी की उपस्थिति दर्ज करें",
"Mark Present":"उपस्थित दर्ज करें",
"Mark Absent":"अनुपस्थित दर्ज करें",
"Mark":"दर्ज करें",
"Note / reason (optional)":"नोट / कारण (वैकल्पिक)",
"Status and salary are updated. Actual time-in/out records are retained.":"स्थिति और वेतन अपडेट होते हैं। वास्तविक आने-जाने का समय सुरक्षित रहता है।",
"No editable dates in this employee’s employment period. Choose another month.":"इस कर्मचारी की नौकरी की अवधि में बदलने योग्य तारीख नहीं है। दूसरा महीना चुनें।",

"Employee Logins & Progress":"कर्मचारी लॉगिन और प्रगति",
"SaaS Clients & Licenses":"सास क्लाइंट और लाइसेंस",
"Create employee login":"कर्मचारी लॉगिन बनाएँ",
"Manage employee logins":"कर्मचारी लॉगिन प्रबंधन",
"Onboarded employees":"जोड़े गए कर्मचारी",
"Logins created":"बनाए गए लॉगिन",
"Login pending":"लॉगिन लंबित",
"Profiles complete":"पूर्ण प्रोफ़ाइल",
"Profile progress":"प्रोफ़ाइल प्रगति",
"Portal login":"पोर्टल लॉगिन",
"Created":"बन गया",
"Pending":"लंबित",
"Login created":"लॉगिन बन गया",
"Add team member":"कर्मचारी जोड़ें",
"Staff name":"कर्मचारी का नाम",
"Set password (minimum 12 characters)":"पासवर्ड रखें (कम से कम 12 अक्षर)",
"Login ID (or use email below)":"लॉगिन आईडी (या नीचे ईमेल दें)",
"Email (optional if Login ID is set)":"ईमेल (लॉगिन आईडी होने पर वैकल्पिक)",
"Portal role":"पोर्टल भूमिका",
"Add client company":"क्लाइंट कंपनी जोड़ें",
"Create company & admin":"कंपनी और एडमिन बनाएँ",
"Client company name":"क्लाइंट कंपनी का नाम",
"Company administrator name":"कंपनी एडमिन का नाम",
"Administrator login email":"एडमिन का लॉगिन ईमेल",
"Plan name":"योजना का नाम",
"License status":"लाइसेंस स्थिति",
"Maximum staff records":"अधिकतम कर्मचारी रिकॉर्ड",
"Billing cycle":"बिलिंग अवधि",
"License fee (₹ per billing period)":"लाइसेंस शुल्क (₹ प्रति अवधि)",
"License valid through (IST; blank = no expiry)":"लाइसेंस की अंतिम तिथि (आईएसटी; खाली = कोई समाप्ति नहीं)",
"Client licenses":"क्लाइंट लाइसेंस",
"Active licenses":"सक्रिय लाइसेंस",
"Suspended / expired":"निलंबित / समाप्त",
"Monthly fee equivalent":"मासिक शुल्क के बराबर",
"Customer subscriptions":"ग्राहक सदस्यताएँ",
"Manage license":"लाइसेंस प्रबंधन",
"Save license":"लाइसेंस सहेजें",
"Copy login link":"लॉगिन लिंक कॉपी करें",
"Company logo on payslips":"वेतन पर्ची पर कंपनी का लोगो",
"Upload / change company logo":"कंपनी का लोगो अपलोड / बदलें",
"No expiry":"कोई समाप्ति नहीं",
"No license enforced":"लाइसेंस प्रतिबंध नहीं",
"Suspended":"निलंबित",
"Expired":"समाप्त",

"Employee portal login":"कर्मचारी पोर्टल लॉगिन",
"Create employee login now":"अभी कर्मचारी का लॉगिन बनाएँ",
"Confirm password":"पासवर्ड की पुष्टि करें",
"Generate password":"पासवर्ड बनाएँ",
"Show password":"पासवर्ड दिखाएँ",
"Existing user ID":"मौजूदा यूज़र आईडी",
"Checking employee login…":"कर्मचारी का लॉगिन जाँचा जा रहा है…",
"Employee login creation is available in the connected WordPress portal.":"कर्मचारी का लॉगिन जुड़े हुए वर्डप्रेस पोर्टल में बनाया जा सकता है।",
"The company Admin can create this employee’s user ID and password.":"कंपनी एडमिन इस कर्मचारी की यूज़र आईडी और पासवर्ड बना सकता है।",
"This employee already has a portal login. Saving details keeps the current password.":"इस कर्मचारी का पोर्टल लॉगिन पहले से है। जानकारी सहेजने पर पासवर्ड वही रहेगा।",
"The employee can access only their own portal. Share these credentials securely; passwords are not shown again after saving.":"कर्मचारी केवल अपना पोर्टल देख सकता है। लॉगिन जानकारी सुरक्षित तरीके से दें; सहेजने के बाद पासवर्ड फिर नहीं दिखाया जाता।",
"Employee details and portal login saved.":"कर्मचारी की जानकारी और पोर्टल लॉगिन सहेज दिया गया।",
"Employee details saved.":"कर्मचारी की जानकारी सहेज दी गई।",
"Passwords do not match.":"दोनों पासवर्ड मेल नहीं खाते।",
"Use a password of 12–128 characters.":"12–128 अक्षरों का पासवर्ड रखें।",
"This user ID is already in use. Choose another user ID.":"यह यूज़र आईडी पहले से उपयोग में है। दूसरी यूज़र आईडी चुनें।",
"User ID must contain 3–60 letters, numbers, dots, hyphens or underscores.":"यूज़र आईडी में 3–60 अंग्रेज़ी अक्षर, अंक, डॉट, हाइफ़न या अंडरस्कोर रखें।",

 'Downloads':'डाउनलोड','Download records':'रिकॉर्ड डाउनलोड करें','Download your records':'अपने रिकॉर्ड डाउनलोड करें','All business records':'सभी व्यावसायिक रिकॉर्ड','Report':'रिपोर्ट','Selected month':'चुना हुआ महीना','All dates':'सभी तारीखें','Date range':'तारीखों की अवधि','Preparing download…':'डाउनलोड तैयार हो रहा है…','Download ready':'डाउनलोड तैयार है','Download PDF':'PDF डाउनलोड करें','Employee records':'कर्मचारी रिकॉर्ड','Detailed attendance':'विस्तृत उपस्थिति','Payroll register':'वेतन रजिस्टर','Saved payslip archive':'सहेजी गई वेतन पर्चियाँ','Leave requests':'छुट्टी अनुरोध','Reimbursement claims':'खर्च प्रतिपूर्ति अनुरोध','Project timesheets':'प्रोजेक्ट टाइमशीट','Meetings and responses':'मीटिंग और जवाब','Performance records':'प्रदर्शन रिकॉर्ड','Help desk tickets':'सहायता टिकट','Attendance corrections':'उपस्थिति सुधार','Tax deductions':'कर कटौतियाँ','Bank transfer worksheet':'बैंक ट्रांसफ़र सूची','Payroll adjustments':'वेतन समायोजन','Compliance review':'अनुपालन समीक्षा','Company settings':'कंपनी सेटिंग्स','Activity log':'गतिविधि लॉग',
 'Sun':'रवि','Mon':'सोम','Tue':'मंगल','Wed':'बुध','Thu':'गुरु','Fri':'शुक्र','Sat':'शनि','Monday':'सोमवार','Tuesday':'मंगलवार','Wednesday':'बुधवार','Thursday':'गुरुवार','Friday':'शुक्रवार','Saturday':'शनिवार','Sunday':'रविवार','No check-in yet':'अभी तक चेक-इन नहीं','Office geo-fence location is still the default':'कार्यालय की जियो-फ़ेंस लोकेशन अभी डिफ़ॉल्ट है',
 'Privacy Policy':'गोपनीयता नीति','Terms & Conditions':'नियम और शर्तें','Refund Policy':'धनवापसी नीति','About Us':'हमारे बारे में',
 'Dashboard':'डैशबोर्ड','Announcements':'घोषणाएँ','Onboarding':'ऑनबोर्डिंग','People':'कर्मचारी','Attendance':'उपस्थिति','Biometric':'बायोमेट्रिक','Time Tracking':'समय ट्रैकिंग','Meetings':'मीटिंग','Performance':'प्रदर्शन','Leaves':'छुट्टियाँ','Payroll':'वेतन प्रक्रिया','Payslips':'वेतन पर्चियाँ','My Payslips':'मेरी वेतन पर्चियाँ','Tax Deductions':'कर कटौतियाँ','Reimbursements':'खर्च प्रतिपूर्ति','Compliance':'अनुपालन','Reports':'रिपोर्ट','Help Desk':'सहायता केंद्र','Settings':'सेटिंग्स','Profile':'प्रोफ़ाइल','AI Tools':'एआई टूल्स','Brand settings':'ब्रांड सेटिंग्स','Launch checklist':'लॉन्च चेकलिस्ट','Companies':'कंपनियाँ','Coupon & quote':'कूपन और कोटेशन','Login accounts':'लॉगिन खाते','Pricing':'मूल्य निर्धारण',
 'WORKSPACE':'कार्यस्थान','PEOPLE & TIME':'कर्मचारी और समय','PAYROLL & FINANCE':'वेतन और वित्त','ADMINISTRATION':'प्रशासन','PRODUCT':'उत्पाद','HR & PAYROLL':'एचआर और वेतन','Company workspace':'कंपनी कार्यस्थान','Manage companies':'कंपनियाँ प्रबंधित करें','Company Admin':'कंपनी एडमिन','HR Manager':'एचआर मैनेजर','Super Admin':'सुपर एडमिन','Administrator':'प्रशासक','Staff':'कर्मचारी','Admin':'एडमिन','Employee':'कर्मचारी','Employees':'कर्मचारी','Logout':'लॉगआउट','Theme':'थीम','Calendar':'कैलेंडर','Calculator':'कैलकुलेटर','Language':'भाषा',
 'Total staff':'कुल कर्मचारी','Present today':'आज उपस्थित','Absent today':'आज अनुपस्थित','Net payroll':'शुद्ध वेतन','Company cost (est.)':'कंपनी लागत (अनुमानित)','Pending approvals':'लंबित स्वीकृतियाँ','Late today':'आज देर से आए','On leave today':'आज छुट्टी पर','departments':'विभाग','Run Payroll':'वेतन तैयार करें','Pay Taxes':'कर भुगतान','Pending':'लंबित','Processed':'तैयार','Last 7 days’ attendance':'पिछले 7 दिनों की उपस्थिति','Department-wise staff':'विभाग अनुसार कर्मचारी','Action items':'ज़रूरी कार्य','Birthdays & work anniversaries (30 days)':'जन्मदिन और कार्य वर्षगाँठ (30 दिन)','Upcoming meetings':'आगामी मीटिंग','Upcoming holidays':'आगामी अवकाश','Today’s attendance':'आज की उपस्थिति','Announcements':'घोषणाएँ','Net pay':'शुद्ध वेतन','PF (emp+er)':'पीएफ (कर्मचारी + नियोक्ता)','ESI (emp+er)':'ईएसआई (कर्मचारी + नियोक्ता)','PT + TDS':'पीटी + टीडीएस','reimbursement claims':'खर्च प्रतिपूर्ति अनुरोध','approved leave':'स्वीकृत छुट्टी','gross + employer PF/ESI':'सकल वेतन + नियोक्ता पीएफ/ईएसआई',
 'Save':'सहेजें','Create':'बनाएँ','Add':'जोड़ें','Submit':'जमा करें','Apply':'लागू करें','Edit':'संपादित करें','Delete':'हटाएँ','Remove':'हटाएँ','Cancel':'रद्द करें','Close':'बंद करें','Close ×':'बंद करें ×','View':'देखें','Open':'खोलें','Download':'डाउनलोड','Print':'प्रिंट','Search':'खोजें','Approve':'स्वीकृत करें','Reject':'अस्वीकृत करें','OK':'स्वीकृत करें','Reset demo':'डेमो रीसेट करें','View Staff Portal':'कर्मचारी पोर्टल देखें','View Admin Portal':'एडमिन पोर्टल देखें','Support team':'सहायता टीम','Help when you need it':'ज़रूरत पर सहायता','Saved':'सहेजा गया','Saving…':'सहेजा जा रहा है…','Browser demo':'ब्राउज़र डेमो','Interactive preview · sample data stored in this browser':'इंटरैक्टिव डेमो · नमूना डेटा इस ब्राउज़र में सुरक्षित है',
 'Portal font':'पोर्टल फ़ॉन्ट','System font':'सिस्टम फ़ॉन्ट','Bold':'बोल्ड','Italic':'इटैलिक','Main color':'मुख्य रंग','Sidebar':'साइडबार','Light':'हल्का','Dark':'गहरा','Page background':'पृष्ठ की पृष्ठभूमि','Soft':'सौम्य','White':'सफ़ेद','Warm':'हल्का गर्म','Cool':'हल्का ठंडा','Default theme par wapas':'डिफ़ॉल्ट थीम पर वापस जाएँ','Apna color':'अपना रंग','Ye theme sirf aapke account par lagti hai.':'यह थीम केवल आपके खाते पर लागू होती है।','Aa Bb 123 · Your people, your style.':'अ आ क ख 123 · आपके लोग, आपकी शैली।',
 'Month':'महीना','Date':'तारीख','Day':'दिन','Name':'नाम','Department':'विभाग','Dept':'विभाग','Present':'उपस्थित','Absent':'अनुपस्थित','Leave':'छुट्टी','Weekly off':'साप्ताहिक अवकाश','Holiday':'अवकाश','Today':'आज','Status':'स्थिति','Time in':'आने का समय','Time out':'जाने का समय','Working hours':'कार्य के घंटे','Punctuality':'समयपालन','Notes':'टिप्पणियाँ','Late':'देर से','On time':'समय पर','Not checked in':'चेक-इन नहीं हुआ','Check-out pending':'चेक-आउट लंबित','Office':'कार्यालय','In':'आने का समय','Out':'जाने का समय','Distance':'दूरी','Muster roll · All employees':'मस्टर रोल · सभी कर्मचारी','P = Present · A = Absent · L = Leave · W = Weekly off · H = Holiday':'P = उपस्थित · A = अनुपस्थित · L = छुट्टी · W = साप्ताहिक अवकाश · H = अवकाश','P = Present, A = Absent, L = Leave, W = Weekly off, H = Holiday':'P = उपस्थित, A = अनुपस्थित, L = छुट्टी, W = साप्ताहिक अवकाश, H = अवकाश','Aaj':'आज','Off':'अवकाश','View in photo':'आने की फ़ोटो देखें','View out photo':'जाने की फ़ोटो देखें','Manual status correction':'मैन्युअल स्थिति सुधार',
 'Download all payslips (A4)':'सभी वेतन पर्चियाँ डाउनलोड करें (A4)','Adjustments':'समायोजन','Bank transfer sheet':'बैंक ट्रांसफ़र सूची','Not processed':'अभी तैयार नहीं','Gross':'सकल वेतन','Net':'शुद्ध वेतन','Paid days':'वेतन वाले दिन','Unpaid days':'अवैतनिक दिन','Present days':'उपस्थित दिन','Total':'कुल','Slip':'वेतन पर्ची','Reimb./Incent.':'खर्च / प्रोत्साहन','SALARY RECORDS':'वेतन रिकॉर्ड','Payslips · Last 12 months':'वेतन पर्चियाँ · पिछले 12 महीने','Choose an employee and month to view, print or download their salary slip.':'वेतन पर्ची देखने, प्रिंट या डाउनलोड करने के लिए कर्मचारी और महीना चुनें।','MONTHLY PAYSLIP':'मासिक वेतन पर्ची','Payslip version':'वेतन पर्ची का संस्करण','View payslip':'वेतन पर्ची देखें','↓ Download':'↓ डाउनलोड','Draft':'ड्राफ़्ट','Finalised':'अंतिम','Latest draft':'नवीनतम ड्राफ़्ट','Latest finalised version':'नवीनतम अंतिम संस्करण','Print / Save as PDF':'प्रिंट / PDF में सहेजें','Download payslip':'वेतन पर्ची डाउनलोड करें','Open payroll register →':'वेतन रजिस्टर खोलें →','Correct historical attendance':'पुरानी उपस्थिति सुधारें','Mark Present / Absent':'उपस्थित / अनुपस्थित अंकित करें','Whole employed month':'नौकरी का पूरा महीना','From date':'शुरुआत की तारीख','To date':'अंतिम तारीख','Attendance status':'उपस्थिति की स्थिति','Reason for this correction':'इस सुधार का कारण','Save attendance':'उपस्थिति सहेजें','Save attendance & revise payslip':'उपस्थिति सहेजें और वेतन पर्ची संशोधित करें','After correction':'सुधार के बाद','Correction history':'सुधार का इतिहास','Dates':'तारीखें','Reason':'कारण','Changed by':'बदलाव करने वाला','Payslip':'वेतन पर्ची','No corrections for this employee and month.':'इस कर्मचारी और महीने के लिए कोई सुधार नहीं है।',
 'TEAM COLLABORATION':'टीम सहयोग','Make room for great conversations.':'अपनी टीम की बातचीत आसान बनाएँ।','Your team’s meetings, links and responses in one place.':'टीम की मीटिंग, लिंक और जवाब एक ही जगह।','Upcoming':'आगामी','Live now':'अभी लाइव','Completed':'पूर्ण','On your schedule':'आपके शेड्यूल में','Ready to join':'जुड़ने के लिए तैयार','Meeting archive':'पुरानी मीटिंग','Past meetings':'पिछली मीटिंग','PLAN AHEAD':'आगे की योजना','Schedule a meeting':'मीटिंग शेड्यूल करें','Schedule meeting':'मीटिंग शेड्यूल करें','Pick a platform, add the details and invite your team.':'प्लेटफ़ॉर्म चुनें, जानकारी भरें और टीम को आमंत्रित करें।','Meeting platform':'मीटिंग प्लेटफ़ॉर्म','Other platform':'अन्य प्लेटफ़ॉर्म','Meeting title':'मीटिंग का शीर्षक','Start time':'शुरुआत का समय','Duration':'अवधि','Host':'आयोजक','Meeting link':'मीटिंग लिंक','Create the meeting on your platform, then paste its link here.':'प्लेटफ़ॉर्म पर मीटिंग बनाएँ और उसका लिंक यहाँ पेस्ट करें।','Invite people':'लोगों को आमंत्रित करें','All employees':'सभी कर्मचारी','A department':'एक विभाग','Selected employees':'चुने हुए कर्मचारी','Select employees':'कर्मचारी चुनें','Agenda / details':'एजेंडा / विवरण','Join meeting ↗':'मीटिंग से जुड़ें ↗','Copy link':'लिंक कॉपी करें','Add to calendar':'कैलेंडर में जोड़ें','Going':'आऊँगा / आऊँगी','Declined':'मना किया','Awaiting response':'जवाब की प्रतीक्षा','Your response':'आपका जवाब','Can’t attend':'शामिल नहीं हो सकूँगा / सकूँगी','✓ Going':'✓ शामिल होऊँगा / होऊँगी','✓ Declined':'✓ मना किया','Your schedule is clear':'अभी कोई मीटिंग नहीं है','Upcoming meetings will appear here.':'आगामी मीटिंग यहाँ दिखाई देंगी।','No upcoming meetings':'कोई आगामी मीटिंग नहीं है','Join ↗':'जुड़ें ↗',
 'Your AI tools, in one place':'आपके एआई टूल्स, एक ही जगह','Choose a tool to open its official website in a new tab.':'किसी टूल की आधिकारिक वेबसाइट नए टैब में खोलने के लिए चुनें।','Assistant':'सहायक','Writing & analysis':'लेखन और विश्लेषण','Research':'शोध','Reasoning & coding':'तर्क और कोडिंग','Image creation':'चित्र बनाना','Productivity':'उत्पादकता','Each service may require its own account or paid plan. Only the website opens; your HR records are not attached to these links.':'हर सेवा के लिए अलग खाता या सशुल्क योजना की ज़रूरत हो सकती है। केवल वेबसाइट खुलती है; आपके एचआर रिकॉर्ड इन लिंक के साथ नहीं भेजे जाते।',
 'Super Admin · Pricing':'सुपर एडमिन · मूल्य निर्धारण','Monthly (₹)':'मासिक (₹)','Quarterly (₹)':'तिमाही (₹)','Annually (₹)':'वार्षिक (₹)','Monthly':'मासिक','Quarterly':'तिमाही','Annually':'वार्षिक','Save pricing':'मूल्य सहेजें','Only Super Admin can change these software prices. Company Admins can view prices and apply eligible coupons.':'केवल सुपर एडमिन सॉफ़्टवेयर के मूल्य बदल सकता है। कंपनी एडमिन मूल्य देख सकता है और मान्य कूपन लगा सकता है।','Prices are quotes. A payment gateway and subscription activation are not connected.':'ये मूल्य कोटेशन के लिए हैं। भुगतान गेटवे और सदस्यता सक्रियण अभी जुड़े नहीं हैं।','Plan':'योजना','Apply coupon':'कूपन लागू करें','Coupon code':'कूपन कोड','Subtotal':'उप-योग','Discount':'छूट','Total payable':'कुल देय','Create company':'कंपनी बनाएँ','Add company':'कंपनी जोड़ें','Company name':'कंपनी का नाम','Company':'कंपनी','Workspace':'कार्यस्थान','Current company':'मौजूदा कंपनी','Separate records':'अलग रिकॉर्ड','Open workspace':'कार्यस्थान खोलें','Company access':'कंपनी की पहुँच','Username or email':'यूज़रनेम या ईमेल','Company role':'कंपनी की भूमिका','Company owner':'कंपनी का मालिक','HR manager':'एचआर प्रबंधक','Save access':'पहुँच सहेजें','Create login':'लॉगिन बनाएँ','User ID':'यूज़र आईडी','User ID / username':'यूज़र आईडी / यूज़रनेम','Name':'नाम','Role':'भूमिका','Account role':'खाते की भूमिका','Employee profile (employee login only)':'कर्मचारी प्रोफ़ाइल (कर्मचारी लॉगिन के लिए)','Select employee':'कर्मचारी चुनें','Initial password (12+ characters)':'प्रारंभिक पासवर्ड (12+ अक्षर)','Email (optional)':'ईमेल (वैकल्पिक)','Revoke access':'पहुँच रद्द करें','Super Admin creates company Admin logins. Company Admin creates employee logins for this company.':'सुपर एडमिन कंपनी एडमिन का लॉगिन बनाता है। कंपनी एडमिन अपने कर्मचारियों के लॉगिन बनाता है।',
 'Add staff':'कर्मचारी जोड़ें','Edit staff':'कर्मचारी संपादित करें','Employee code':'कर्मचारी कोड','Designation':'पद','Date of birth':'जन्म तिथि','Date of joining':'नियुक्ति तिथि','Basic + DA (monthly)':'मूल वेतन + डीए (मासिक)','HRA':'एचआरए','Other allowance':'अन्य भत्ता','Professional tax (monthly)':'व्यावसायिक कर (मासिक)','TDS (monthly)':'टीडीएस (मासिक)','Bank name':'बैंक का नाम','Account number':'खाता संख्या','IFSC code':'आईएफएससी कोड','Account holder name':'खाताधारक का नाम','Search staff...':'कर्मचारी खोजें...','Title':'शीर्षक','Message':'संदेश','Type':'प्रकार','Amount':'राशि','Check-in':'चेक-इन','Check-out':'चेक-आउट','No upcoming meeting':'कोई आगामी मीटिंग नहीं',
 'e.g. Monthly team review':'जैसे: मासिक टीम समीक्षा','What will your team discuss?':'आपकी टीम किन विषयों पर बात करेगी?','For example: attendance register verified by HR':'जैसे: एचआर ने उपस्थिति रजिस्टर सत्यापित किया','Login':'लॉगिन','Admin login':'एडमिन लॉगिन','Staff login':'कर्मचारी लॉगिन','Username':'यूज़रनेम','Password':'पासवर्ड','Welcome back':'आपका स्वागत है','Open Admin Demo':'एडमिन डेमो खोलें','Open Staff Demo':'कर्मचारी डेमो खोलें'
};
const aliases={
 'Aaj present':'Present today','Aaj absent':'Absent today','Late aaj':'Late today','Leave pe aaj':'On leave today','Pichhle 7 din ki attendance':'Last 7 days’ attendance','Department wise staff':'Department-wise staff','Birthday aur work anniversary (30 din)':'Birthdays & work anniversaries (30 days)','Aaj ki attendance':'Today’s attendance','Meri payslips':'My Payslips','abhi tak punch nahi':'No check-in yet','Koi upcoming meeting nahi':'No upcoming meetings','Muster roll - sabhi staff':'Muster roll · All employees','Platform par naya link banayein':'Create a meeting link','Link copy':'Copy link','Office geo-fence location abhi default hai':'Office geo-fence location is still the default'
};
const reverse=new Map(Object.entries(labels).map(([en,hi])=>[hi,en]));
const language=()=>ses?thGet().lang:'en';
function translate(value,lang){
 const before=value.match(/^\s*/)[0],after=value.match(/\s*$/)[0],text=value.trim();if(!text)return value;
 let original=aliases[text]||reverse.get(text)||text;
 const messages=[[/^Payroll (\d{4}-\d{2}) abhi process nahi hua$/,'Payroll $1 is not processed'],[/^(\d+) reimbursement claim approval ke liye pending$/,'$1 reimbursement claims awaiting approval'],[/^(\d+) leave request pending$/,'$1 leave requests pending'],[/^(\d+) attendance correction request pending$/,'$1 attendance corrections pending'],[/^(\d+) help desk ticket open$/,'$1 open help desk tickets'],[/^(\d+) performance review baaki \((.+)\)$/,'$1 performance reviews pending ($2)'],[/^(\d+) compliance item pending \((.+)\)$/,'$1 compliance items pending ($2)'],[/^(\d+) staff ka UAN missing$/,'$1 employees missing UAN'],[/^(\d+) staff ka profile ya documents incomplete$/,'$1 employee profiles or documents incomplete']];
 for(const [pattern,replacement]of messages)if(pattern.test(original)){original=original.replace(pattern,replacement);break}
 let result=lang==='hi'?(labels[original]||original):original;
 if(lang==='hi'&&result===original){
  const patterns=[[/^Payroll (\d{4}-\d{2}) is not processed$/,'वेतन $1 अभी तैयार नहीं है'],[/^(\d+) reimbursement claims awaiting approval$/,'$1 खर्च अनुरोध स्वीकृति के लिए लंबित'],[/^(\d+) leave requests pending$/,'$1 छुट्टी अनुरोध लंबित'],[/^(\d+) attendance corrections pending$/,'$1 उपस्थिति सुधार लंबित'],[/^(\d+) open help desk tickets$/,'$1 सहायता टिकट खुले हैं'],[/^(\d+) performance reviews pending \((.+)\)$/,'$1 प्रदर्शन समीक्षाएँ लंबित ($2)'],[/^(\d+) compliance items pending \((.+)\)$/,'$1 अनुपालन कार्य लंबित ($2)'],[/^(\d+) employees missing UAN$/,'$1 कर्मचारियों का यूएएन नहीं है'],[/^(\d+) employee profiles or documents incomplete$/,'$1 कर्मचारी प्रोफ़ाइल या दस्तावेज़ अधूरे हैं'],[/^Detailed attendance · (.+)$/,'विस्तृत उपस्थिति · $1'],[/^Payroll breakup \((.+)\)$/,'वेतन विवरण ($1)'],[/^Payroll (\d{4}-\d{2}):$/,'वेतन $1:'],[/^(\d+) departments$/,'$1 विभाग'],[/^(\d+)% attendance$/,'$1% उपस्थिति'],[/^Present (\d+)$/,'उपस्थित $1'],[/^Absent (\d+)$/,'अनुपस्थित $1'],[/^Leave (\d+)$/,'छुट्टी $1'],[/^Weekly off (\d+)$/,'साप्ताहिक अवकाश $1'],[/^Holiday (\d+)$/,'अवकाश $1'],[/^(\d+) minutes$/,'$1 मिनट'],[/^(\d+) scheduled$/,'$1 निर्धारित'],[/^(\d+) completed$/,'$1 पूर्ण'],[/^(\d+) records$/,'$1 रिकॉर्ड'],[/^Revision (\d+)$/,'संशोधन $1'],[/^Create (.+) link ↗$/,'$1 लिंक बनाएँ ↗'],[/^Host · (.+)$/,'आयोजक · $1'],[/^Processed (.+)$/,'तैयार $1'],[/^shift (.+)$/,'शिफ़्ट $1']];
  for(const [pattern,replacement]of patterns)if(pattern.test(original)){result=original.replace(pattern,replacement);break}
 }
 return before+result+after;
}
const ignore='script,style,textarea,.sl,.bk .br,.header-user-name,.wl-company strong,#mc-active,#history-employee,#attendance-employee,#ac-employee,.meeting-card-title h3,.meeting-agenda,.meeting-host strong,.ai-tool strong,[data-i18n-ignore],[data-no-translate]';
let applying=false;
function apply(root=document){
 if(applying)return;applying=true;try{
  const lang=language();document.documentElement.lang=lang;
  for(const region of root===document?document.querySelectorAll('#app,#wgt,#dpop,#history-slip-dialog .history-dialog-head,#history-slip-dialog .history-dialog-actions,#access-dialog,#tst'):[root]){
   const walker=document.createTreeWalker(region,NodeFilter.SHOW_TEXT);let node;
   while(node=walker.nextNode()){
    const parent=node.parentElement;if(!parent||parent.closest(ignore))continue;
    if(parent.closest('td:first-child')&&node.textContent.trim()!=='Total')continue;
    const translated=translate(node.textContent,lang);if(translated!==node.textContent)node.textContent=translated;
   }
   for(const el of region.querySelectorAll('[placeholder],[title],[aria-label]')){
    for(const key of ['placeholder','title','aria-label']){const value=el.getAttribute(key);if(value){const next=translate(value,lang);if(value!==next)el.setAttribute(key,next)}}
   }
  }
 }finally{applying=false}
}
function selector(){
 const bar=document.querySelector('#app .top .u');if(!bar||document.getElementById('portal-language'))return;
 const select=document.createElement('select');select.id='portal-language';select.setAttribute('aria-label','Language');select.innerHTML='<option value="en">English</option><option value="hi">हिन्दी</option>';select.value=language();select.onchange=()=>thSet({lang:select.value});bar.prepend(select);
}
const render=window.draw;window.draw=function(...args){const result=render.apply(this,args);selector();apply();return result};
let queued=false;new MutationObserver(()=>{if(queued)return;queued=true;queueMicrotask(()=>{queued=false;apply()})}).observe(document.body,{childList:true,subtree:true,characterData:true});
window.HRMSLanguage={translate,apply};selector();apply();
})();
