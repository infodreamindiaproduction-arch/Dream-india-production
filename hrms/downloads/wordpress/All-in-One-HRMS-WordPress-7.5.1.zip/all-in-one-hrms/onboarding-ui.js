/* Employee credentials stay in this form's memory, separate from HR records. */
(function(){'use strict';
const boot=window.DREAMPEOPLE||null,canCreate=!!(boot&&boot.mode!=='employee'&&boot.canBrand);
let draft,loading=false,linked=null,checkedId=null,busy=false,generation=0;
function reset(){draft={enabled:false,username:'',password:'',confirm:''};linked=null;checkedId=null;loading=false;generation++}
reset();
if(boot)OF.Job=OF.Job.filter(field=>field[0]!=='pin');
for(const name of ['startNew','startEdit','cancelOB']){const old=window[name];window[name]=function(...args){if(busy)return;reset();return old.apply(this,args)}}
function form(){
 let html='<fieldset id="ob-login" style="margin:20px 0;padding:18px;border:1px solid var(--bd);border-radius:12px"><legend><b>Employee portal login</b></legend>';
 if(!boot)return html+'<p class="mu">Employee login creation is available in the connected WordPress portal.</p></fieldset>';
 if(!canCreate)return html+'<p class="mu">The company Admin can create this employee’s user ID and password.</p></fieldset>';
 if(OBid&&checkedId!==OBid)return html+'<p class="mu" id="ob-login-status" role="status">Checking employee login…</p></fieldset>';
 if(linked)return html+'<p><span>Existing user ID</span>: <b data-no-translate>'+esc(linked)+'</b></p><p class="mu">This employee already has a portal login. Saving details keeps the current password.</p></fieldset>';
 return html+'<label for="ob-login-enable" style="display:flex;align-items:center;gap:9px"><input id="ob-login-enable" type="checkbox"'+(draft.enabled?' checked':'')+'> Create employee login now</label><div id="ob-login-fields"'+(!draft.enabled?' hidden':'')+'><div class="g" style="margin-top:14px"><div><label for="ob-login-user">User ID / username</label><input id="ob-login-user" maxlength="60" pattern="[A-Za-z0-9_.-]{3,60}" autocomplete="off" autocapitalize="none" spellcheck="false"></div><div><label for="ob-login-password">Initial password (12+ characters)</label><input id="ob-login-password" type="password" minlength="12" maxlength="128" autocomplete="new-password"></div><div><label for="ob-login-confirm">Confirm password</label><input id="ob-login-confirm" type="password" minlength="12" maxlength="128" autocomplete="new-password"></div></div><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:10px"><button id="ob-login-generate" type="button">Generate password</button><label for="ob-login-show"><input id="ob-login-show" type="checkbox"> Show password</label></div><p class="mu">The employee can access only their own portal. Share these credentials securely; passwords are not shown again after saving.</p></div></fieldset>';
}
const oldForm=window.vOF;
window.vOF=function(){return oldForm().replace('<p id="om"',form()+'<p id="om"')};
async function loadStatus(id){
 if(loading)return;loading=true;const token=generation;
 try{
  const url=new URL(boot.api+'reference/onboarding');url.searchParams.set('employee',id);
  const r=await fetch(url,{credentials:'same-origin',headers:{'X-WP-Nonce':boot.nonce,'X-HRMS-Company':String(boot.companyId||1)}});
  const result=await r.json();if(!r.ok)throw Error(result.message||'Employee login could not be checked.');
  if(token!==generation||id!==OBid)return;
  linked=result.linked?result.username:null;checkedId=id;draw();
 }catch(e){if(token===generation){const status=document.getElementById('ob-login-status');if(status){status.textContent=e.message;status.className='no'}}}
 finally{if(token===generation)loading=false}
}
function bind(){
 if(!document.getElementById('ob-login'))return;
 if(canCreate&&OBid&&checkedId!==OBid){loadStatus(OBid);return}
 const enabled=document.getElementById('ob-login-enable');if(!enabled)return;
 const user=document.getElementById('ob-login-user'),password=document.getElementById('ob-login-password'),confirm=document.getElementById('ob-login-confirm');
 user.value=draft.username;password.value=draft.password;confirm.value=draft.confirm;
 const sync=()=>{draft.enabled=enabled.checked;document.getElementById('ob-login-fields').hidden=!draft.enabled;for(const input of [user,password,confirm]){input.required=draft.enabled;input.disabled=!draft.enabled}};
 enabled.onchange=sync;sync();
 user.oninput=()=>draft.username=user.value;
 password.oninput=()=>draft.password=password.value;
 confirm.oninput=()=>draft.confirm=confirm.value;
 document.getElementById('ob-login-show').onchange=e=>{password.type=confirm.type=e.target.checked?'text':'password'};
 document.getElementById('ob-login-generate').onclick=()=>{
  const bytes=crypto.getRandomValues(new Uint8Array(20)),alphabet='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
  draft.password=draft.confirm=Array.from(bytes,b=>alphabet[b%alphabet.length]).join('');password.value=draft.password;confirm.value=draft.confirm;
 };
}
const oldDraw=window.draw;window.draw=function(){oldDraw();bind()};
window.HRMSOnboarding={connected:!!boot,busy:()=>busy,save:async function(employee){
 if(busy)throw Error('Employee details are already being saved.');
 const payload={employee};let created=false,username='';
 if(draft.enabled){
  if(!canCreate)throw Error('Only the company Admin can create employee logins.');
  username=draft.username.trim();
  if(!/^[A-Za-z0-9_.-]{3,60}$/.test(username))throw Error('User ID must contain 3–60 letters, numbers, dots, hyphens or underscores.');
  if(draft.password.length<12||draft.password.length>128)throw Error('Use a password of 12–128 characters.');
  if(draft.password!==draft.confirm)throw Error('Passwords do not match.');
  payload.login={username,password:draft.password};created=true;
 }
 busy=true;
 const controls=[...document.querySelectorAll('#om ~ div button,#ob-login input,#ob-login button')];
 const prior=controls.map(input=>input.disabled);controls.forEach(input=>input.disabled=true);
 try{
  await HRMSStore.action('reference/onboarding',payload);
  if(created){linked=username;checkedId=employee.id;draft={enabled:false,username:'',password:'',confirm:''}}
  return created?'Employee details and portal login saved.':'Employee details saved.';
 }finally{busy=false;controls.forEach((input,i)=>input.disabled=prior[i])}
}};
})();
