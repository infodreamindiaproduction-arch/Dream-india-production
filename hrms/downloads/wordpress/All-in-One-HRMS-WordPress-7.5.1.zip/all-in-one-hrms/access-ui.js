(function(){'use strict';
const boot=window.DREAMPEOPLE||null,employeePage='Employee Logins & Progress',saasPage='SaaS Clients & Licenses';
const owner=()=>!!(boot&&boot.canBrand),superAdmin=()=>!!(boot&&boot.canCreateCompany),E=value=>esc(value),$=id=>document.getElementById(id);
let accounts=null,clients=null,loadingAccounts=null,loadingClients=null,search='',filter='all',accountGeneration=0,clientGeneration=0;
const money=value=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:2}).format(Number(value||0)/100);
async function api(path,body){const r=await fetch(boot.api+path,{method:body===undefined?'GET':'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-WP-Nonce':boot.nonce,'X-HRMS-Company':String(boot.companyId)},...(body===undefined?{}:{body:JSON.stringify(body)})});const data=await r.json();if(!r.ok)throw Error(data.message||'Request failed.');return data}
const accountFor=id=>(accounts||[]).find(a=>a.role==='employee'&&Number(a.employee_id)===Number(id));
const pending=()=>D.emps.filter(e=>!accountFor(e.id));
function badge(text,type=''){return '<span class="access-badge '+type+'">'+E(text)+'</span>'}
function head(eyebrow,title,description,buttons){return '<div class="access-heading"><div><span class="access-eyebrow">'+E(eyebrow)+'</span><h2>'+E(title)+'</h2><p class="mu">'+E(description)+'</p></div><div class="access-actions">'+buttons+'</div></div>'}
function cards(items){return '<div class="access-stats">'+items.map(([label,value])=>'<div class="c"><span class="mu">'+E(label)+'</span><strong>'+E(value)+'</strong></div>').join('')+'</div>'}
function employeeView(){
 const ready=accounts!==null,created=ready?D.emps.filter(e=>accountFor(e.id)).length:'—';
 return head('COMPANY / TEAM',employeePage,'Create a portal login after employee onboarding and track profile completion.','<button id="access-print">Print A4</button><button id="access-download">Download CSV</button><button class="p" id="access-onboard">+ Add team member</button>')+
 cards([['Onboarded employees',D.emps.length],['Logins created',created],['Login pending',ready?pending().length:'—'],['Profiles complete',D.emps.filter(e=>pct(e).p===100).length]])+
 '<section class="access-callout"><div><b>Manage employee logins</b><p>Select an onboarded employee and set their user ID and password.</p></div><button class="p" id="access-create"'+(!ready||!pending().length?' disabled':'')+'>Create employee login</button></section><section class="c access-team"><div class="access-table-tools"><div><button data-access-filter="all">All</button> <button data-access-filter="pending">Login pending</button> <button data-access-filter="created">Login created</button></div><label><span class="access-sr">Search team</span><input id="access-search" placeholder="Search team" value="'+E(search)+'"></label></div><p id="access-load-error" class="no" role="alert"></p><div class="w"><table><thead><tr><th>Employee</th><th>Department / Role</th><th>Branch</th><th>Profile progress</th><th>Portal login</th><th></th></tr></thead><tbody id="access-team-rows"></tbody></table></div>'+(!D.emps.length?'<div class="access-empty"><b>A fresh start for your team</b><p>Add your first team member, then create their employee login.</p><button class="p" id="access-empty-onboard">+ Add team member</button></div>':'')+'</section>';
}
function tableRows(){
 const body=$('access-team-rows');if(!body)return;
 const rows=D.emps.filter(e=>{const a=accountFor(e.id);return (filter==='all'||filter==='created'&&a||filter==='pending'&&!a)&&[e.name,e.code,e.dept,e.des,e.loc,a?.user_login].join(' ').toLowerCase().includes(search.toLowerCase())});
 body.innerHTML=accounts===null?'<tr><td colspan="6">Loading employee logins…</td></tr>':rows.map(e=>{const a=accountFor(e.id),progress=pct(e).p;return '<tr><td><b>'+E(e.name)+'</b><br><span class="mu">'+E(e.code)+'</span></td><td>'+E(e.dept||'—')+'<br><span class="mu">'+E(e.des||'—')+'</span></td><td>'+E(e.loc||'—')+'</td><td><progress max="100" value="'+progress+'" aria-label="Profile completion"></progress><br>'+progress+'%</td><td>'+(a?badge('Created','green')+'<br><span data-no-translate>'+E(a.user_login)+'</span>':badge('Pending','amber'))+'</td><td>'+(a?'<button data-access-profile="'+e.id+'">View profile</button>':'<button class="p" data-access-employee="'+e.id+'">Create login</button>')+'</td></tr>'}).join('')||(D.emps.length?'<tr><td colspan="6">No matching employees.</td></tr>':'');
 for(const b of body.querySelectorAll('[data-access-employee]'))b.onclick=()=>employeeModal(Number(b.dataset.accessEmployee));
 for(const b of body.querySelectorAll('[data-access-profile]'))b.onclick=()=>{tab='Onboarding';startEdit(Number(b.dataset.accessProfile),0)};
 for(const b of document.querySelectorAll('[data-access-filter]'))b.classList.toggle('p',b.dataset.accessFilter===filter);
}
function bindEmployees(){
 $('access-print').onclick=()=>window.print();$('access-onboard').onclick=onboard;$('access-empty-onboard')?.addEventListener('click',onboard);
 $('access-create').onclick=()=>employeeModal();$('access-search').oninput=e=>{search=e.target.value;tableRows()};
 for(const b of document.querySelectorAll('[data-access-filter]'))b.onclick=()=>{filter=b.dataset.accessFilter;tableRows()};
 $('access-download').onclick=async()=>{if(accounts===null)return;const rows=[['Employee code','Employee','Department','Designation','Branch','Profile complete (%)','Login status','User ID'],...D.emps.map(e=>[e.code,e.name,e.dept,e.des,e.loc,pct(e).p,accountFor(e.id)?'Created':'Pending',accountFor(e.id)?.user_login||''])];await svF('Employee_logins_progress.csv',csv(rows))};
 tableRows();
}
function onboard(){tab='Onboarding';startNew()}
function updateBadge(){const b=$('access-nav-pending');if(b)b.textContent=accounts===null?'…':pending().length}
async function loadAccounts(force=false){
 if(loadingAccounts&&!force)return loadingAccounts;if(accounts!==null&&!force)return;const generation=++accountGeneration;
 loadingAccounts=api('accounts').then(rows=>{if(generation!==accountGeneration)return;accounts=rows;updateBadge();if(tab===employeePage)renderCustom()}).catch(e=>{if($('access-load-error'))$('access-load-error').textContent=e.message}).finally(()=>{if(generation===accountGeneration)loadingAccounts=null});
 return loadingAccounts;
}
function dialog(title,subtitle,body){
 $('access-dialog')?.remove();const node=document.createElement('dialog');node.id='access-dialog';node.className='access-dialog';
 node.innerHTML='<div class="access-dialog-head"><div><h2>'+E(title)+'</h2><p>'+E(subtitle)+'</p></div><button type="button" data-close aria-label="Close">×</button></div><form id="access-dialog-form" autocomplete="off"><div class="access-dialog-body">'+body+'<p id="access-dialog-error" class="no" role="alert"></p></div><div class="access-dialog-foot"><button type="button" data-close>Cancel</button><button class="p" id="access-dialog-save">'+E(title)+'</button></div></form>';
 document.body.append(node);let busy=false;
 const close=()=>{if(!busy){node.querySelectorAll('[autocomplete="new-password"]').forEach(input=>input.value='');node.remove()}};
 for(const b of node.querySelectorAll('[data-close]'))b.onclick=close;
 node.addEventListener('cancel',e=>{e.preventDefault();close()});node.addEventListener('close',()=>node.remove());node.showModal();
 return {node,form:$('access-dialog-form'),close,setBusy(value){busy=value;for(const b of node.querySelectorAll('button,input,select'))b.disabled=value}};
}
function field(label,id,type='text',value='',attrs=''){return '<div><label for="'+id+'">'+E(label)+'</label><input id="'+id+'" type="'+type+'" value="'+E(value)+'" '+attrs+'></div>'}
function passwordFields(prefix){return field('Set password (minimum 12 characters)',prefix+'-password','password','','required minlength="12" maxlength="128" autocomplete="new-password"')+field('Confirm password',prefix+'-confirm','password','','required minlength="12" maxlength="128" autocomplete="new-password"')}
function showPasswords(prefix){$('access-show-password').onchange=e=>{for(const suffix of ['password','confirm'])$(prefix+'-'+suffix).type=e.target.checked?'text':'password'}}
function employeeModal(id){
 if(!owner()||accounts===null)return;const people=pending();if(!people.length){toast('Every onboarded employee already has a login.');return}
 const m=dialog('Create employee login','Choose an onboarded employee. Login access applies only to their own records.','<div class="access-form-grid"><div><label for="access-staff">Staff name</label><select id="access-staff" required>'+people.map(e=>'<option value="'+e.id+'"'+(e.id===id?' selected':'')+'>'+E(e.name)+' · '+E(e.code)+'</option>').join('')+'</select></div>'+field('Login ID (or use email below)','access-user','text','','maxlength="60" autocapitalize="none" spellcheck="false" autocomplete="off"')+field('Email (optional if Login ID is set)','access-email','email','','maxlength="100" autocomplete="off"')+field('Portal role','access-role','text','Employee','readonly')+field('Designation','access-designation','text','','readonly')+passwordFields('access')+'</div><label class="access-check"><input type="checkbox" id="access-show-password"> Show password</label><p class="access-note">Share the initial credentials securely. Passwords are never displayed again after saving.</p>');
 const sync=()=>{const e=D.emps.find(e=>e.id===Number($('access-staff').value));$('access-designation').value=e?.des||'';$('access-email').value=e?.email||''};$('access-staff').onchange=sync;sync();showPasswords('access');
 m.form.onsubmit=async event=>{event.preventDefault();try{
  const email=$('access-email').value.trim(),username=$('access-user').value.trim()||email,password=$('access-password').value;
  if(!/^[A-Za-z0-9_.@-]{3,60}$/.test(username))throw Error('Set a Login ID of 3–60 characters, or use an email address of up to 60 characters.');
  if(password.length<12||password.length>128)throw Error('Use a password of 12–128 characters.');
  if(password!==$('access-confirm').value)throw Error('Passwords do not match.');
  m.setBusy(true);await api('accounts',{role:'employee',employee:Number($('access-staff').value),username,email,password});
  $('access-password').value=$('access-confirm').value='';accounts=null;await loadAccounts(true);m.setBusy(false);m.close();toast('Employee login created.');
 }catch(e){$('access-dialog-error').textContent=e.message;m.setBusy(false)}};
}
function clientStatus(row){return !row.license?'No license enforced':row.license.status==='suspended'?'Suspended':row.active?'Active':'Expired'}
function saasView(){
 const list=clients||[],licensed=list.filter(c=>c.license),active=licensed.filter(c=>c.active),equivalent=active.reduce((sum,c)=>sum+c.license.fee/({monthly:1,quarterly:3,annually:12}[c.license.cycle]||1),0);
 return head('SUPER ADMIN / SOFTWARE CLIENTS',saasPage,'Create a separate company administrator for each customer. Manage plans and access from your Super Admin account.','<button id="saas-refresh">Refresh</button><button class="p" id="saas-add">+ Add client company</button>')+
 cards([['Client licenses',licensed.length],['Active licenses',active.length],['Suspended / expired',licensed.length-active.length],['Monthly fee equivalent',money(equivalent)]])+
 '<div class="access-callout"><p>You are the Super Admin. Client Admins manage only their assigned company. Suspended or expired licenses block company Admin, HR and Employee access. Fees are tracked manually; no automatic charges.</p></div><section class="c"><h3>Customer subscriptions</h3><p id="saas-error" class="no" role="alert"></p><div class="w"><table><thead><tr><th>Company</th><th>Company Admin</th><th>Plan / Fee</th><th>Staff limit</th><th>Valid through (IST)</th><th>Status</th><th></th></tr></thead><tbody>'+(clients===null?'<tr><td colspan="7">Loading client companies…</td></tr>':list.map(c=>'<tr><td><b>'+E(c.name)+'</b></td><td>'+c.admins.map(a=>'<span>'+E(a.display_name)+'</span><br><span class="mu">'+E(a.user_email||a.user_login)+'</span>').join('<br>')+'</td><td>'+E(c.license?.plan||'Existing workspace')+'<br>'+money(c.license?.fee)+' / '+E(c.license?.cycle||'—')+'</td><td>'+c.staff+' / '+(c.license?.maxStaff||'—')+'</td><td>'+E(c.license?.validUntil||'No expiry')+'</td><td>'+badge(clientStatus(c),c.active?'green':'amber')+'</td><td><button data-saas-edit="'+c.id+'">Manage license</button> <button data-saas-copy="'+c.id+'">Copy login link</button></td></tr>').join(''))+'</tbody></table></div></section>';
}
function bindSaas(){
 $('saas-add').onclick=()=>clientModal();$('saas-refresh').onclick=()=>loadClients(true);
 for(const b of document.querySelectorAll('[data-saas-edit]'))b.onclick=()=>clientModal(clients.find(c=>c.id===Number(b.dataset.saasEdit)));
 for(const b of document.querySelectorAll('[data-saas-copy]'))b.onclick=async()=>{try{await navigator.clipboard.writeText(clients.find(c=>c.id===Number(b.dataset.saasCopy)).loginUrl);toast('Login link copied.')}catch{toast(clients.find(c=>c.id===Number(b.dataset.saasCopy)).loginUrl)}};
}
async function loadClients(force=false){if(loadingClients&&!force)return loadingClients;if(clients!==null&&!force)return;const generation=++clientGeneration;loadingClients=api('saas/clients').then(r=>{if(generation!==clientGeneration)return;clients=r.clients;if(tab===saasPage)renderCustom()}).catch(e=>{if($('saas-error'))$('saas-error').textContent=e.message}).finally(()=>{if(generation===clientGeneration)loadingClients=null});return loadingClients}
function clientModal(row){
 if(!superAdmin())return;const l=row?.license||{plan:'Business',status:'active',maxStaff:25,cycle:'monthly',fee:49900,validUntil:''};
 const body='<div class="access-form-grid">'+(!row?field('Client company name','saas-name','text','','required maxlength="100"')+field('Company administrator name','saas-admin','text','','required maxlength="100"')+field('Administrator login email','saas-email','email','','required maxlength="100" autocomplete="off"')+passwordFields('saas'):'<div class="access-note">'+E(row.name)+'</div>')+field('Plan name','saas-plan','text',l.plan,'required maxlength="100"')+'<div><label for="saas-status">License status</label><select id="saas-status"><option value="active"'+(l.status==='active'?' selected':'')+'>Active</option><option value="suspended"'+(l.status==='suspended'?' selected':'')+'>Suspended</option></select></div>'+field('Maximum staff records','saas-limit','number',l.maxStaff,'required min="1" max="1000" step="1"')+'<div><label for="saas-cycle">Billing cycle</label><select id="saas-cycle">'+['monthly','quarterly','annually'].map(c=>'<option'+(l.cycle===c?' selected':'')+'>'+c+'</option>').join('')+'</select></div>'+field('License fee (₹ per billing period)','saas-fee','number',l.fee/100,'required min="0" max="1000000" step="0.01"')+field('License valid through (IST; blank = no expiry)','saas-until','date',l.validUntil)+'</div>'+(!row?'<label class="access-check"><input id="access-show-password" type="checkbox"> Show password</label>':'')+'<p class="access-note">Each new company starts with empty staff records and its own Admin login. The client can upload its own payslip logo. Company Admin logins are managed by Super Admin.</p>';
 const m=dialog(row?'Save license':'Create company & admin',row?'Renew, suspend or update this customer’s license.':'Create a client company and its separate administrator login.',body);
 if(!row){showPasswords('saas');$('saas-fee').oninput=()=>{$('saas-fee').dataset.edited='true'};$('saas-cycle').onchange=async()=>{try{const p=await api('pricing');$('saas-fee').value=(p.prices[$('saas-cycle').value]/100).toFixed(2)}catch(e){$('access-dialog-error').textContent=e.message}};api('pricing').then(p=>{if(m.node.isConnected&&!$('saas-fee').dataset.edited)$('saas-fee').value=(p.prices.monthly/100).toFixed(2)}).catch(()=>{})}
 m.form.onsubmit=async event=>{event.preventDefault();try{
  const license={plan:$('saas-plan').value.trim(),status:$('saas-status').value,maxStaff:Number($('saas-limit').value),cycle:$('saas-cycle').value,fee:Math.round(Number($('saas-fee').value)*100),validUntil:$('saas-until').value};
  let body,path;if(row){path='saas/license';body={company:row.id,revision:row.license?.revision||0,license}}
  else{const password=$('saas-password').value;if(password.length<12||password.length>128)throw Error('Use a password of 12–128 characters.');if(password!==$('saas-confirm').value)throw Error('Passwords do not match.');path='saas/clients';body={name:$('saas-name').value.trim(),adminName:$('saas-admin').value.trim(),adminEmail:$('saas-email').value.trim(),password,license}}
  m.setBusy(true);await api(path,body);m.node.querySelectorAll('[autocomplete="new-password"]').forEach(input=>input.value='');await loadClients(true);m.setBusy(false);m.close();toast(row?'License saved.':'Client company and administrator created.');
 }catch(e){$('access-dialog-error').textContent=e.message;m.setBusy(false)}};
}
function renderCustom(){const host=$('access-content');if(!host)return;host.innerHTML=tab===employeePage?employeeView():saasView();tab===employeePage?bindEmployees():bindSaas()}
function nav(){
 if(ses?.r!=='a')return;
 const side=document.querySelector('.sb');if(!side)return;
 if(owner()){
  const b=document.createElement('button');b.id='employee-logins-nav';b.className='mi '+(tab===employeePage?'on':'');b.innerHTML='<i>♙</i><span>Employee Logins &amp; Progress</span><span id="access-nav-pending" class="access-nav-count">…</span>';b.onclick=()=>{tab=employeePage;draw();loadAccounts(true)};
  const onboarding=[...side.querySelectorAll('.mi')].find(n=>n.textContent.includes('Onboarding'));if(onboarding)onboarding.after(b);else side.append(b);updateBadge();
 }
 if(superAdmin()){const b=document.createElement('button');b.id='saas-clients-nav';b.className='mi '+(tab===saasPage?'on':'');b.innerHTML='<i>♧</i>SaaS Clients &amp; Licenses';b.onclick=()=>{tab=saasPage;draw();loadClients(true)};side.append(b)}
}
const priorDraw=window.draw;window.draw=function(){
 const wanted=tab,custom=wanted===employeePage&&owner()||wanted===saasPage&&superAdmin();
 if([employeePage,saasPage].includes(wanted)&&!custom)tab='Dashboard';
 if(custom)tab='Settings';priorDraw();
 if(custom){tab=wanted;const main=document.querySelector('.mn'),top=main?.querySelector('.top'),bar=main?.querySelector('.demo-bar');if(main){main.replaceChildren(...[top,bar].filter(Boolean));top.querySelector('h1').textContent=wanted;const host=document.createElement('div');host.id='access-content';main.append(host);renderCustom()}for(const b of document.querySelectorAll('.sb .mi.on'))b.classList.remove('on')}
 nav();if(owner()&&accounts===null)loadAccounts();if(custom&&wanted===saasPage&&clients===null)loadClients();
};
const priorOnboarding=window.vOnb;window.vOnb=function(){const html=priorOnboarding();return owner()&&OSt===null&&!LET?'<section class="access-callout"><div><b>Employee Logins &amp; Progress</b><p>Create login IDs and passwords after onboarding.</p></div><button class="p" onclick="tab=\''+employeePage+'\';draw()">Manage employee logins</button></section>'+html:html};
const previousAction=HRMSStore.action;HRMSStore.action=async function(path,payload){const result=await previousAction.call(this,path,payload);if(path==='reference/onboarding'){accounts=null;accountGeneration++;loadingAccounts=null;}return result};
})();
