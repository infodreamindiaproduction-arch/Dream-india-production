<?php
if (!defined('ABSPATH')) { exit; }

function dip_onboarding_account($employee_id) {
    global $wpdb;
    list($companies, $members) = dip_company_tables();
    return $wpdb->get_row($wpdb->prepare(
        "SELECT u.user_login FROM $members m INNER JOIN {$wpdb->users} u ON u.ID=m.user_id WHERE m.company_id=%d AND m.employee_id=%d AND m.role='employee'",
        dip_company_id(), $employee_id
    ), ARRAY_A);
}

function dip_onboarding_remove_account($user_id) {
    global $wpdb;
    list($companies, $members) = dip_company_tables();
    $wpdb->delete($members, array('company_id'=>dip_company_id(), 'user_id'=>$user_id), array('%d','%d'));
    require_once ABSPATH.'wp-admin/includes/user.php';
    wp_delete_user($user_id);
}

function dip_onboarding_create_account($login, $employee) {
    if (!dip_company_can_brand()) {
        return new WP_Error('onboarding_denied', 'Only the company Admin can create employee logins.', array('status'=>403));
    }
    if (!is_array($login) || array_diff(array_keys($login), array('username','password'))) {
        return new WP_Error('onboarding_login', 'Enter an employee user ID and password.', array('status'=>422));
    }
    $username = $login['username'] ?? '';
    $password = $login['password'] ?? '';
    if (!is_string($username) || !preg_match('/^[A-Za-z0-9_.-]{3,60}$/D', $username) || !validate_username($username)) {
        return new WP_Error('onboarding_username', 'User ID must contain 3–60 letters, numbers, dots, hyphens or underscores.', array('status'=>422));
    }
    if (!is_string($password) || strlen($password)<12 || strlen($password)>128) {
        return new WP_Error('onboarding_password', 'Use a password of 12–128 characters.', array('status'=>422));
    }
    if (username_exists($username)) {
        return new WP_Error('onboarding_username', 'This user ID is already in use. Choose another user ID.', array('status'=>422));
    }
    if (dip_onboarding_account($employee['id'])) {
        return new WP_Error('employee_linked', 'This employee already has a login. Save their details without creating another login.', array('status'=>422));
    }
    $id = wp_insert_user(array(
        'user_login'=>$username, 'user_pass'=>$password,
        'user_email'=>$employee['email'] ?? '', 'display_name'=>$employee['name'],
        'role'=>'dreampeople_employee'
    ));
    if (is_wp_error($id)) {
        return new WP_Error('onboarding_account', $id->get_error_message(), array('status'=>422));
    }
    global $wpdb;
    list($companies, $members) = dip_company_tables();
    $linked = $wpdb->insert($members, array(
        'company_id'=>dip_company_id(), 'user_id'=>$id, 'role'=>'employee', 'employee_id'=>$employee['id']
    ));
    if (!$linked) {
        dip_onboarding_remove_account($id);
        return new WP_Error('onboarding_account', 'Could not link the employee login. No employee details were saved.', array('status'=>409));
    }
    return array('userId'=>$id, 'username'=>$username);
}

add_action('rest_api_init', function() {
    register_rest_route('dreampeople/v1', '/reference/onboarding', array(
        array('methods'=>'GET', 'permission_callback'=>'dip_company_can_brand', 'callback'=>function($r) {
            $id = (string)$r->get_param('employee');
            if (!preg_match('/^[1-9][0-9]*$/D', $id)) {
                return new WP_Error('employee_missing', 'Choose an employee in this company.', array('status'=>422));
            }
            list($w) = dip_ref_read();
            if (!array_filter($w['data']['emps'], fn($e)=>$e['id']===(int)$id)) {
                return new WP_Error('employee_missing', 'Employee not found in this company.', array('status'=>404));
            }
            $account = dip_onboarding_account((int)$id);
            return array('linked'=>(bool)$account, 'username'=>$account['user_login'] ?? null);
        }),
        array('methods'=>'POST', 'permission_callback'=>'dp_can_manage', 'callback'=>function($r) {
            if (strlen($r->get_body())>100000) {
                return new WP_Error('onboarding_size', 'Employee details are too large.', array('status'=>413));
            }
            $p = $r->get_json_params();
            $create_login = isset($p['login']);
            if ($create_login && !dip_company_can_brand()) {
                return new WP_Error('onboarding_denied', 'Only the company Admin can create employee logins.', array('status'=>403));
            }
            list($w, $raw) = dip_ref_read();
            if (($p['revision'] ?? null)!==$w['revision']) {
                return new WP_Error('onboarding_conflict', 'Another user saved changes. Refresh before retrying.', array('status'=>409));
            }
            $profile = $p['employee'] ?? null;
            $fields = array('id','code','name','father','dob','gender','marital','blood','mobile','email','emerg','emergNo','addr1','addr2','dept','des','doj','etype','mgr','loc','uan','pfno','esic','regime','nominee','nrel','bank','acc','ach','aadhaar','pan','ifsc','basic','hra','oth','pt','tds');
            if (!is_array($profile) || array_diff(array_keys($profile), $fields) || !is_int($profile['id'] ?? null) || $profile['id']<1) {
                return new WP_Error('onboarding_profile', 'Enter valid employee details. Login credentials must stay separate from the profile.', array('status'=>422));
            }
            foreach (array_diff($fields, array('id','basic','hra','oth','pt','tds')) as $field) {
                if (isset($profile[$field]) && !is_string($profile[$field])) {
                    return new WP_Error('onboarding_profile', 'Employee text fields must contain text.', array('status'=>422));
                }
            }
            if (!empty($profile['email']) && !is_email($profile['email'])) {
                return new WP_Error('onboarding_email', 'Enter a valid personal email, or leave it blank.', array('status'=>422));
            }
            $s = $w['data'];
            $index = null;
            foreach ($s['emps'] as $i=>$employee) {
                if ($employee['id']===$profile['id']) { $index=$i; break; }
            }
            $employee = array_merge($index===null ? array('docs'=>array(), 'ph'=>'') : $s['emps'][$index], $profile);
            if ($index===null) { $s['emps'][]=$employee; }
            else { $s['emps'][$index]=$employee; }
            try { $s=dip_ref_validate($s, $w['data']); }
            catch (InvalidArgumentException $e) { return new WP_Error('onboarding_profile', $e->getMessage(), array('status'=>422)); }
            // Use the sanitised profile for the WordPress identity as well.
            foreach ($s['emps'] as $candidate) { if ($candidate['id']===$profile['id']) { $employee=$candidate; break; } }
            $account = null;
            if ($create_login) {
                $account = dip_onboarding_create_account($p['login'], $employee);
                if (is_wp_error($account)) { return $account; }
            }
            $result = dip_ref_commit($w, $raw, $s);
            if (is_wp_error($result)) {
                // A concurrent workspace save must not leave a new login behind.
                if ($account) { dip_onboarding_remove_account($account['userId']); }
                return $result;
            }
            $data = $result->get_data();
            $data['account'] = $account ? array('created'=>true, 'username'=>$account['username']) : array('created'=>false);
            $result->set_data($data);
            return $result;
        })
    ));
});
