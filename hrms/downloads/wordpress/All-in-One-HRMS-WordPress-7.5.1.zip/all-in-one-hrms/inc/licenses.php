<?php
if (!defined('ABSPATH')) { exit; }

function dip_license_key($id) { return 'hrms_client_license_'.(int)$id; }
function dip_license_read($id) { return get_option(dip_license_key($id), null); }
function dip_license_active($license) {
    $today=(new DateTimeImmutable('now', new DateTimeZone('Asia/Kolkata')))->format('Y-m-d');
    return $license===null || (($license['status']??'')==='active' && (empty($license['validUntil']) || $license['validUntil']>=$today));
}
function dip_license_access($id) { return current_user_can('manage_options') || dip_license_active(dip_license_read($id)); }
function dip_license_staff_limit($count, $previous=0) {
    $license=dip_license_read(dip_company_id());
    if ($license && $count>(int)$license['maxStaff'] && $count>$previous) {
        throw new InvalidArgumentException('The company staff limit has been reached. Ask Super Admin to update the license.');
    }
}
function dip_license_validate($input) {
    if (!is_array($input)) { throw new InvalidArgumentException('Enter license details.'); }
    $plan=$input['plan']??''; $cycle=$input['cycle']??''; $status=$input['status']??'';
    $limit=$input['maxStaff']??null; $fee=$input['fee']??null; $until=$input['validUntil']??'';
    if (!is_string($plan)||!trim($plan)||strlen($plan)>300) { throw new InvalidArgumentException('Enter a plan name under 100 characters.'); }
    if (!in_array($cycle,array('monthly','quarterly','annually'),true)||!in_array($status,array('active','suspended'),true)) { throw new InvalidArgumentException('Choose a valid billing cycle and license status.'); }
    if (!is_int($limit)||$limit<1||$limit>1000||!is_int($fee)||$fee<0||$fee>100000000) { throw new InvalidArgumentException('Staff limit must be 1–1000; enter a valid license fee.'); }
    if (!is_string($until)||($until!==''&&!dp_date($until))) { throw new InvalidArgumentException('Enter a valid license expiry date, or leave it blank.'); }
    return array('plan'=>sanitize_text_field($plan),'cycle'=>$cycle,'status'=>$status,'maxStaff'=>$limit,'fee'=>$fee,'validUntil'=>$until,'updatedBy'=>get_current_user_id(),'updatedAt'=>gmdate('c'));
}
function dip_saas_client_row($company) {
    global $wpdb;
    $id=(int)$company['id']; list($companies,$members)=dip_company_tables();
    $admins=$wpdb->get_results($wpdb->prepare("SELECT u.ID,u.user_login,u.user_email,u.display_name FROM $members m INNER JOIN {$wpdb->users} u ON u.ID=m.user_id WHERE m.company_id=%d AND m.role='owner' ORDER BY u.ID",$id),ARRAY_A);
    $key=$id===1?'dreampeople_reference_v3':'dreampeople_reference_v3_c'.$id;
    $state=get_option($key); $license=dip_license_read($id);
    return array('id'=>$id,'name'=>$company['name'],'admins'=>$admins,'staff'=>count($state['data']['emps']??array()),'license'=>$license,'active'=>dip_license_active($license),'loginUrl'=>wp_login_url(dip_portal_url()));
}
function dip_saas_response($data) {
    $response=rest_ensure_response($data); $response->header('Cache-Control','private, no-store, max-age=0'); return $response;
}
add_filter('rest_pre_dispatch',function($result,$server,$request) {
    if ($result!==null||!is_user_logged_in()||current_user_can('manage_options')) { return $result; }
    $route=$request->get_route();
    if (str_starts_with($route,'/dreampeople/v1/')&&!str_starts_with($route,'/dreampeople/v1/sales/')) {
        $id=dip_company_id();
        if ($id>0&&!dip_license_access($id)) { return new WP_Error('license_inactive','This company license is suspended or expired. Contact your company administrator.',array('status'=>403)); }
    }
    return $result;
},9,3);

add_action('rest_api_init',function() {
    register_rest_route('dreampeople/v1','/saas/clients',array(
        array('methods'=>'GET','permission_callback'=>fn()=>current_user_can('manage_options'),'callback'=>function() {
            global $wpdb; list($companies)=dip_company_tables();
            return dip_saas_response(array('clients'=>array_map('dip_saas_client_row',$wpdb->get_results("SELECT id,name FROM $companies ORDER BY id",ARRAY_A))));
        }),
        array('methods'=>'POST','permission_callback'=>fn()=>current_user_can('manage_options'),'callback'=>function($request) {
            if (strlen($request->get_body())>20000) { return new WP_Error('client_size','Request too large.',array('status'=>413)); }
            $p=$request->get_json_params();
            try { $license=dip_license_validate($p['license']??null); }
            catch(InvalidArgumentException $e) { return new WP_Error('license_invalid',$e->getMessage(),array('status'=>422)); }
            $name=$p['name']??''; $admin=$p['adminName']??''; $email=$p['adminEmail']??''; $password=$p['password']??'';
            if (!is_string($name)||!trim($name)||strlen($name)>300||!is_string($admin)||!trim($admin)||strlen($admin)>300||!is_string($email)||strlen($email)>100||!is_email($email)||email_exists($email)||!is_string($password)||strlen($password)<12||strlen($password)>128) {
                return new WP_Error('client_invalid','Enter company/admin names, a unique administrator email and a 12–128 character password.',array('status'=>422));
            }
            $name=sanitize_text_field($name); $admin=sanitize_text_field($admin);
            if (!$name||!$admin) { return new WP_Error('client_invalid','Company and administrator names are required.',array('status'=>422)); }
            global $wpdb; list($companies,$members)=dip_company_tables();
            if (!$wpdb->insert($companies,array('name'=>$name,'created_by'=>get_current_user_id(),'created_at'=>gmdate('Y-m-d H:i:s')))) {
                return new WP_Error('client_create','The company could not be created.',array('status'=>500));
            }
            $id=(int)$wpdb->insert_id; $uid=0;
            $previous=$GLOBALS['hrms_request_company']??null; $GLOBALS['hrms_request_company']=$id;
            try {
                $username='client_'.str_replace('-','',wp_generate_uuid4());
                $user=wp_insert_user(array('user_login'=>$username,'user_pass'=>$password,'user_email'=>$email,'display_name'=>$admin,'role'=>'dreampeople_hr_manager'));
                if (is_wp_error($user)) { throw new RuntimeException('Administrator account could not be created.'); }
                $uid=(int)$user;
                if (!$wpdb->insert($members,array('company_id'=>$id,'user_id'=>$uid,'role'=>'owner'))) { throw new RuntimeException('Administrator account could not be linked.'); }
                $license['revision']=1;
                if (!add_option(dip_license_key($id),$license,'',false)) { throw new RuntimeException('The license could not be saved.'); }
                update_user_meta($uid,'hrms_active_company',$id);
                dip_ref_read();
                return dip_saas_response(dip_saas_client_row(array('id'=>$id,'name'=>$name)));
            } catch(RuntimeException $e) {
                $wpdb->delete($members,array('company_id'=>$id));
                if ($uid) { require_once ABSPATH.'wp-admin/includes/user.php'; wp_delete_user($uid); }
                delete_option(dip_license_key($id)); delete_option('dreampeople_reference_v3_c'.$id);
                $wpdb->delete($companies,array('id'=>$id));
                return new WP_Error('client_create',$e->getMessage().' No client company was retained.',array('status'=>500));
            } finally {
                if ($previous===null) { unset($GLOBALS['hrms_request_company']); }
                else { $GLOBALS['hrms_request_company']=$previous; }
            }
        })
    ));
    register_rest_route('dreampeople/v1','/saas/license',array('methods'=>'POST','permission_callback'=>fn()=>current_user_can('manage_options'),'callback'=>function($request) {
        $p=$request->get_json_params(); $id=$p['company']??null;
        if (!is_int($id)||!dip_company_exists($id)) { return new WP_Error('client_missing','Choose an existing company.',array('status'=>404)); }
        try { $license=dip_license_validate($p['license']??null); }
        catch(InvalidArgumentException $e) { return new WP_Error('license_invalid',$e->getMessage(),array('status'=>422)); }
        global $wpdb; $key=dip_license_key($id);
        $raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$key));
        $old=$raw===null?null:maybe_unserialize($raw);
        if (($p['revision']??null)!==($old['revision']??0)) { return new WP_Error('license_conflict','License changed. Refresh before retrying.',array('status'=>409)); }
        $license['revision']=($old['revision']??0)+1;
        $ok=$raw===null?add_option($key,$license,'',false):$wpdb->query($wpdb->prepare("UPDATE {$wpdb->options} SET option_value=%s WHERE option_name=%s AND BINARY option_value=BINARY %s",maybe_serialize($license),$key,$raw));
        if (!$ok) { return new WP_Error('license_conflict','The license could not be saved. Refresh before retrying.',array('status'=>409)); }
        wp_cache_delete($key,'options');
        $company=$wpdb->get_row($wpdb->prepare('SELECT id,name FROM '.dip_company_tables()[0].' WHERE id=%d',$id),ARRAY_A);
        return dip_saas_response(dip_saas_client_row($company));
    }));
});
