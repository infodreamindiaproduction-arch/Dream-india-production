/* Consistent colours for actions, without changing their behaviour or permissions. */
(function(){'use strict';
const render=window.draw;
function decorate(){
    const main=document.querySelector('#app .mn');if(main)main.dataset.page=tab;
    for(const button of document.querySelectorAll('#app .mn button, #history-slip-dialog button')){
        if(button.matches('.ib,.sw,[data-wl-color],.meeting-platform')||button.closest('.wl-swatches'))continue;
        if(button.dataset.hrmsAction)continue;
        const label=button.textContent.trim(),text=label.toLowerCase(),handler=button.getAttribute('onclick')||'';
        let action='neutral';
        if(/rejected|\bdel[A-Z]|delete|\.splice\(|\brm[A-Z]|revoke/i.test(handler)||/^(delete|remove|revoke|reject|reset demo)\b/.test(text)||button.hasAttribute('data-revoke-account'))action='delete';
        else if(/approved/.test(handler)||/^(approve|ok|accept)\b/.test(text))action='approve';
        else if(/^(run payroll|pay taxes|finalise|finalize|bank transfer)\b/.test(text)||button.classList.contains('tax'))action='finance';
        else if(/^(download|export|print)\b/.test(text)||/[↓]/.test(label)||/\b(dl[A-Z]|svF|printSlip)\(/.test(handler))action='download';
        else if(/^(edit|adjustments|revise|change|update|pin badlein)\b/.test(text))action='edit';
        else if(/^(save|create|add|submit|apply|check-in|start|send|post|login)\b/.test(text)||button.classList.contains('p'))action='save';
        else if(/^(view|open|review|manage|join|copy|set up)\b/.test(text))action='view';
        button.dataset.hrmsAction=action;
        if(label==='x'&&action==='delete'&&!button.getAttribute('aria-label'))button.setAttribute('aria-label',/rejected/.test(handler)?'Reject request':'Delete record');
    }
}
window.draw=function(...args){const result=render.apply(this,args);decorate();return result};
// Dialog actions are added outside the page render; decorate only those new nodes.
const observer=new MutationObserver(changes=>{if(changes.some(change=>[...change.addedNodes].some(node=>node.nodeType===1&&(node.id==='history-slip-dialog'||node.closest?.('#history-slip-dialog')))))decorate()});
observer.observe(document.body,{childList:true,subtree:true});
decorate();
})();
