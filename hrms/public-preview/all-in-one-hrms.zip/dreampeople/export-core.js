/* Explicit business-record projections. Credentials, biometric templates and document blobs are never exported. */
(function(root){'use strict';
const clone=x=>JSON.parse(JSON.stringify(x)),num=x=>Number.isFinite(Number(x))?Number(x):0;
function sheet(key,title,headers,rows,types=[],layout='table'){return {key,title,headers,rows,types:headers.map((_,i)=>types[i]||'text'),layout}}
function context(state,input={}){
 const c={role:'manager',employeeId:0,employee:0,month:null,now:new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Kolkata'}),...input};
 if(c.role==='employee')c.employee=num(c.employeeId);
 if(c.month&&!/^\d{4}-(0[1-9]|1[0-2])$/.test(c.month))throw Error('Choose a valid month');
 c.people=(state.emps||[]).filter(e=>c.role!=='employee'||e.id===c.employeeId);
 if(c.employee&&!c.people.some(e=>e.id===c.employee))throw Error('Employee is not available to this account');
 if(c.role==='employee'&&!c.people.length)throw Error('Employee profile is not available');
 c.people=c.people.filter(e=>!c.employee||e.id===c.employee);c.ids=new Set(c.people.map(e=>e.id));return c;
}
function payslip(state,employeeId,month,version='latest',input={}){
 if(input.role!=='employee'&&!(state.emps||[]).some(e=>e.id===employeeId)&&state.snap?.[month]?.[employeeId]?.e)state={...state,emps:[...(state.emps||[]),state.snap[month][employeeId].e]};
 const c=context(state,{...input,employee:employeeId,month});const e=c.people.find(e=>e.id===employeeId);if(!e)throw Error('Employee is not available to this account');
 const versions=state.slipHistory?.[month]?.[employeeId]||[],selected=version==='latest'?versions.at(-1):versions.find(v=>v.version===Number(version));
 if(version!=='latest'&&!selected&&!(Number(version)===1&&state.snap?.[month]?.[employeeId]&&!versions.length))throw Error('Payslip version not found');
 const locked=!!state.run?.[month],stored=selected?.snapshot||(locked?state.snap?.[month]?.[employeeId]:null);
 if(c.role==='employee'&&!stored)throw Error('A finalised payslip is not available for this month');
 const calc=stored||(root.DreamIndiaEngine?.calculate(state,e,month));if(!calc)throw Error('Payroll calculation is unavailable');
 const record={month,version:selected?.version||calc.revision||1,status:locked&&stored?'Finalised':'DRAFT · Not finalised',issuedAt:selected?.at||state.run?.[month]||'',snapshot:clone(calc),company:clone(selected?.company||state.payrollCompany?.[month]||state.co||{}),policySource:selected?.policySource||'',note:selected?.note||''};
 delete record.snapshot.e?.ph;return record;
}
const payHeaders=['Employee code','Employee','Department','Month','Status','Version','Present days','Paid days','Days in month','Basic + DA (INR)','HRA (INR)','Other allowance (INR)','Gross (INR)','Incentive (INR)','Reimbursement (INR)','Employee PF (INR)','Employee ESI (INR)','Professional tax (INR)','TDS (INR)','Advance (INR)','Net pay (INR)','Employer PF + EDLI (INR)','Employer ESI (INR)','Bank','Account number','IFSC','Issued at','Payslip company'];
const payTypes=payHeaders.map((_,i)=>i>=5&&i<=22?'number':'text');
function payRow(record){const s=record.snapshot,e=s.e||{};return [e.code,e.name,e.dept,record.month,record.status,record.version,num(s.pr),num(s.paid),num(s.dm),num(s.b),num(s.h),num(s.o),num(s.g),num(s.inc),num(s.rbo??num(s.rb)-num(s.inc)),num(s.pfE),num(s.esE),num(s.pt),num(s.td),num(s.ad),num(s.net),num(s.pfR),num(s.esR),e.bank,e.acc,e.ifsc,record.issuedAt,record.company.name]}
function payslipSheet(record){const report=sheet('payslip','Payslip',payHeaders,[payRow(record)],payTypes);report.company=record.company.name;report.period=record.month;report.payslip=record;return report}
function reports(state,key,input={}){
 const c=context(state,input),people=c.people,who=id=>people.find(e=>e.id===id)||{},own=items=>(items||[]).filter(x=>c.ids.has(x.eid)),period=date=>!c.month||String(date||'').slice(0,7)===c.month;
 const needMonth=()=>{if(!c.month)throw Error('Select a month for this report')},admin=()=>{if(c.role==='employee')throw Error('This report is available only to company administrators')};
 let result=[];
 if(key==='employees'){
  const fields=[['Code','code'],['Employee','name'],['Department','dept'],['Designation','des'],['Joined','doj'],['Exit','exit'],['Email','email'],['Phone','mobile'],['Date of birth','dob'],['Gender','gender'],['Father / spouse','father'],['Address','addr1'],['Aadhaar number','aadhaar'],['PAN','pan'],['Basic + DA (INR)','basic','number'],['HRA (INR)','hra','number'],['Other allowance (INR)','oth','number'],['Professional tax (INR)','pt','number'],['TDS (INR)','tds','number'],['UAN','uan'],['ESIC','esic'],['Bank','bank'],['Account holder','ach'],['Account number','acc'],['IFSC','ifsc']];
  result=[sheet(key,'Employee records',fields.map(f=>f[0]),people.map(e=>fields.map(f=>f[2]==='number'?num(e[f[1]]):e[f[1]]||'')),fields.map(f=>f[2]||'text'),'record')];
 }else if(key==='attendance'){
  needMonth();const rows=[],end=new Date(Date.UTC(+c.month.slice(0,4),+c.month.slice(5),0)).getUTCDate();
  for(const e of people)for(let day=1;day<=end;day++){
   const date=c.month+'-'+String(day).padStart(2,'0');if(date>c.now||e.doj&&date<e.doj||e.exit&&date>e.exit)continue;
   const punch=state.att?.[e.id+'|'+date]||{},manual=state.manualAttendance?.[e.id+'|'+date],leave=(state.leaves||[]).find(q=>q.eid===e.id&&q.st==='approved'&&q.from<=date&&q.to>=date),holiday=(state.ann||[]).find(q=>q.cat==='Holiday'&&q.hd===date),off=state.cfg?.paySun&&new Date(date+'T12:00:00Z').getUTCDay()===0;
   const status=manual?.status||(leave?'Leave':punch.in?'Present':holiday?'Holiday':off?'Weekly off':date===c.now?'Not checked in':'Absent');
   const mins=time=>time?num(time.split(':')[0])*60+num(time.split(':')[1]):null,start=mins(punch.in),finish=mins(punch.out),hours=start!==null&&finish!==null?Math.max(0,finish-start)/60:null;
   rows.push([e.code,e.name,e.dept,date,status,punch.in||'',punch.out||'',hours===null?'':Math.round(hours*100)/100,punch.in&&status==='Present'?(start>mins(state.cfg?.shift||'09:30')+num(state.cfg?.grace??15)?'Late':'On time'):'',manual?'Manual correction':punch.dev?'Device':punch.reg?'Approved correction':punch.site||(punch.in?'Office':''),manual?.note||leave?.type||holiday?.title||'']);
  }
  result=[sheet(key,'Detailed attendance',['Code','Employee','Department','Date','Status','Time in','Time out','Hours','Punctuality','Source','Notes'],rows,Array.from({length:11},(_,i)=>i===7?'number':'text'))];
 }else if(key==='payroll'||key==='payslip-archive'){
  if(key==='payroll')needMonth();const months=key==='payroll'?[c.month]:Object.keys(state.run||{}).filter(m=>!c.month||m===c.month).sort();const rows=[];
  for(const month of months){const employees=[...people];if(key==='payslip-archive'&&c.role!=='employee'&&!c.employee)for(const snap of Object.values(state.snap?.[month]||{}))if(snap.e&&!employees.some(e=>e.id===snap.e.id))employees.push(snap.e);
   for(const e of employees){if(e.doj&&e.doj>month+'-31'||e.exit&&e.exit<month+'-01')continue;if(c.role==='employee'&&!state.snap?.[month]?.[e.id])continue;rows.push(payRow(payslip(state,e.id,month,'latest',c)))}
  }
  result=[sheet(key,key==='payroll'?'Payroll register':'Saved payslip archive',payHeaders,rows,payTypes)];
 }else if(key==='leaves'){
  result=[sheet(key,'Leave requests',['Code','Employee','Type','From','To','Days','Reason','Status'],own(state.leaves).filter(x=>!c.month||x.from<=c.month+'-31'&&x.to>=c.month+'-01').map(x=>[who(x.eid).code,who(x.eid).name,x.type,x.from,x.to,num(x.days),x.r,x.st]),['text','text','text','text','text','number'])];
 }else if(key==='expenses'){
  result=[sheet(key,'Reimbursement claims',['Code','Employee','Date','Type','Amount (INR)','Reason','Status'],own(state.reim).filter(x=>period(x.d)).map(x=>[who(x.eid).code,who(x.eid).name,x.d,x.type,num(x.amt),x.note,x.st]),['text','text','text','text','number'])];
 }else if(key==='timesheets'){
  result=[sheet(key,'Project timesheets',['Code','Employee','Date','Project','Task','Minutes','Hours','Source','Notes'],own(state.ts).filter(x=>period(x.d)).map(x=>[who(x.eid).code,who(x.eid).name,x.d,x.p,x.t,num(x.mins),Math.round(num(x.mins)/60*100)/100,x.src,x.note]),['text','text','text','text','text','number','number'])];
 }else if(key==='announcements'){
  result=[sheet(key,'Announcements and holidays',['Title','Category','Published','Event / holiday date','Pinned','Message'],(state.ann||[]).filter(x=>period(x.date)).map(x=>[x.title,x.cat,x.date,x.hd,x.pin?'Yes':'No',x.body]),[],'record')];
 }else if(key==='meetings'){
  const allowed=(state.mt||[]).filter(m=>c.role!=='employee'||m.inv==='all'||m.inv==='dept:'+who(c.employeeId).dept||(m.sel||[]).includes(c.employeeId)).filter(m=>period(m.date));
  result=[sheet(key,'Meetings',['Title','Platform','Date','Time','Duration (minutes)','Host','Audience','Link','Agenda'],allowed.map(m=>[m.title,{meet:'Google Meet',teams:'Microsoft Teams',zoom:'Zoom',other:'Other'}[m.plat]||m.plat,m.date,m.time,num(m.dur),m.host,m.inv,m.link,m.desc]),['text','text','text','text','number']),sheet('meeting-rsvp','Meeting responses',['Meeting','Code','Employee','Response'],allowed.flatMap(m=>Object.entries(m.rsvp||{}).filter(([id])=>c.ids.has(Number(id))).map(([id,value])=>[m.title,who(+id).code,who(+id).name,value==='y'?'Going':value==='n'?'Declined':value])))];
 }else if(key==='performance'){
  const p=state.perf||{},cycles=(p.cycles||[]).filter(x=>!c.cycle||x.id===c.cycle),ids=new Set(cycles.map(x=>x.id)),reviews=[];
  for(const [key,review]of Object.entries(p.rev||{})){const[cycle,id]=key.split('|').map(Number);if(!c.ids.has(id)||!ids.has(cycle))continue;for(const source of ['self','mgr']){const r=review[source];if(!r||c.role==='employee'&&source==='mgr'&&!r.pub)continue;reviews.push([who(id).code,who(id).name,cycles.find(x=>x.id===cycle)?.name||String(cycle),source==='self'?'Self':'Manager',r.pub?'Published':r.sub?'Submitted':'Draft',r.at||'',r.comment||'',r.ach||'',Object.entries(r.ratings||{}).map(([k,v])=>k+': '+v).join('; '),r.incr??'',r.promo?'Yes':'No'])}}
  const publicName=id=>(state.emps||[]).find(e=>e.id===id)?.name||(id===0?'HR Admin':'Employee');
  result=[sheet('goals','Performance goals',['Code','Employee','Cycle','Goal','Weight','Target','Due','Progress (%)','Status'],(p.goals||[]).filter(g=>c.ids.has(g.eid)&&ids.has(g.cid)).map(g=>[who(g.eid).code,who(g.eid).name,cycles.find(x=>x.id===g.cid)?.name,g.title,num(g.weight),g.target,g.due,num(g.prog),g.st]),['text','text','text','text','number','text','text','number']),sheet('reviews','Performance reviews',['Code','Employee','Cycle','Review by','Status','Date','Comments','Achievements','Ratings','Increment (%)','Promotion'],reviews,[],'record'),sheet('cycles','Review cycles',['Cycle','From','To','Due','Status'],cycles.map(x=>[x.name,x.from,x.to,x.due,x.status])),sheet('kudos','Team recognition',['From','To','Date','Category','Message'],(p.kudos||[]).filter(k=>(!c.employee&&c.role!=='employee')||k.from===c.employee||k.to===c.employee).map(k=>[publicName(k.from),publicName(k.to),k.date,k.tag,k.msg]))];
 }else if(key==='helpdesk'){
  const tickets=own(state.tk).filter(t=>!c.status||c.status==='all'||t.st===c.status);
  result=[sheet(key,'Help desk tickets',['Ticket','Code','Employee','Category','Priority','Subject','Message','Status','Created','Updated','Replies'],tickets.map(t=>[String(t.no||t.id),who(t.eid).code,who(t.eid).name,t.cat,t.pri,t.sub,t.body,t.st,t.d,t.u,(t.msgs||[]).map(m=>(m.d||'')+' · '+(m.n||m.by||'')+': '+(m.t||'')).join('\n')]),[],'record')];
 }else if(key==='corrections'){
  result=[sheet('attendance-requests','Attendance correction requests',['Code','Employee','Date','Requested time in','Requested time out','Reason','Status'],own(state.reg).filter(x=>period(x.d)).map(x=>[who(x.eid).code,who(x.eid).name,x.d,x.in,x.out,x.r,x.st])),sheet('correction-history','Attendance correction history',['Code','Employee','From','To','Status','Reason','Actor','Changed at','Payslip revision'],(state.attendanceHistory||[]).filter(x=>c.ids.has(x.employee)&&(!c.month||x.month===c.month)).map(x=>[who(x.employee).code,who(x.employee).name,x.from,x.to,x.status,x.note,x.actor,x.at,x.slipRevision||'']))];
 }else if(key==='tax'||key==='bank'||key==='adjustments'){
  admin();needMonth();const records=people.map(e=>payslip(state,e.id,c.month,'latest',c));
  if(key==='tax')result=[sheet(key,'Employee deductions',['Code','Employee','Gross (INR)','Employee PF (INR)','Employer PF + EDLI (INR)','Employee ESI (INR)','Employer ESI (INR)','PT (INR)','TDS (INR)','UAN','ESIC'],records.map(r=>{const s=r.snapshot,e=s.e;return[e.code,e.name,num(s.g),num(s.pfE),num(s.pfR),num(s.esE),num(s.esR),num(s.pt),num(s.td),e.uan,e.esic]}),['text','text','number','number','number','number','number','number','number'])];
  if(key==='bank')result=[sheet(key,'Bank transfer worksheet',['Code','Employee','Account holder','Bank','Account number','IFSC','Net pay (INR)','Payroll status'],records.map(r=>{const e=r.snapshot.e;return[e.code,e.name,e.ach||e.name,e.bank,e.acc,e.ifsc,num(r.snapshot.net),r.status]}),['text','text','text','text','text','text','number'])];
  if(key==='adjustments')result=[sheet(key,'Payroll adjustments',['Code','Employee','Month','Incentive (INR)','Advance (INR)','Notes'],people.map(e=>{const x=state.adj?.[c.month]?.[e.id]||{};return[e.code,e.name,c.month,num(x.inc),num(x.ad),x.note||'']}),['text','text','text','number','number'])];
 }else if(key==='compliance'){
  admin();needMonth();const total=people.map(e=>payslip(state,e.id,c.month,'latest',c).snapshot).reduce((s,x)=>({pf:s.pf+num(x.pfE)+num(x.pfR),esi:s.esi+num(x.esE)+num(x.esR),tds:s.tds+num(x.td),pt:s.pt+num(x.pt)}),{pf:0,esi:0,tds:0,pt:0});
  result=[sheet(key,'Compliance review',['Item','Month','Amount (INR)','Marked paid date'],[['PF (EPFO ECR)',c.month,total.pf,state.paid?.['PF (EPFO ECR)|'+c.month]||'Pending'],['ESI (ESIC challan)',c.month,total.esi,state.paid?.['ESI (ESIC challan)|'+c.month]||'Pending'],['TDS',c.month,total.tds,state.paid?.['TDS|'+c.month]||'Pending'],['Professional tax',c.month,total.pt,state.paid?.['Professional tax|'+c.month]||'Pending']],['text','text','number'])];
 }else if(key==='devices'){
  admin();result=[sheet(key,'Attendance devices',['Device','Location','Model','Last sync'],(state.dev||[]).map(x=>[x.name,x.loc,x.model,x.last]))];
 }else if(key==='settings'){
  admin();const cfg=state.cfg||{};result=[sheet(key,'Company and payroll settings',['Setting','Value'],[['Company',state.co?.name],['Address',state.co?.addr],['Email',state.co?.email],['Phone',state.co?.phone],['GSTIN',state.co?.gstin],['Website',state.co?.web],...['shift','grace','shiftHrs','half','pfCap','paySun','esiLim','pfE','esE','esR','cl','sl','elv'].map(k=>[k,typeof cfg[k]==='boolean'?(cfg[k]?'Yes':'No'):cfg[k]??''])])];
 }else if(key==='audit'){
  admin();result=[sheet(key,'Activity log',['Date','User','Activity'],(state.log||[]).filter(x=>period(x.t)).map(x=>[x.t,x.u,x.m]))];
 }else throw Error('Unknown report');
 for(const report of result){report.company??=state.co?.name||'';report.period??=c.month||'All dates';report.rows=report.rows.map(row=>row.map((value,i)=>report.types[i]==='number'&&value!==''?num(value):String(value??'')))}
 return result;
}
function csvCell(value){if(typeof value==='number'&&Number.isFinite(value))return String(value);let text=String(value??'');if(/^[\s\uFEFF]*[=+@-]/.test(text)||/^[\t\r]/.test(text))text="'"+text;return '"'+text.replace(/"/g,'""')+'"'}
function csv(reportList,all=false){
 let rows;if(!all&&reportList.length===1){const r=reportList[0];rows=[['Company','Report','Period',...r.headers],...r.rows.map(row=>[r.company,r.title,r.period,...row])]}
 else rows=[['Company','Dataset','Period','Record','Field','Value'],...reportList.flatMap(r=>r.rows.flatMap((row,n)=>row.map((value,i)=>[r.company,r.title,r.period,n+1,r.headers[i],value])))];
 return '\uFEFF'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n');
}
const api={context,reports,payslip,payslipSheet,payRow,csv,csvCell};root.HRMSExportCore=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
