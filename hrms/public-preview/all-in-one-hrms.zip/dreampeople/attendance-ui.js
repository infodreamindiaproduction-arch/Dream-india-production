/* Employee calendar and detailed check-in/out records, matching the requested layout. */
(function(){'use strict';const E=value=>window.esc(value);
window.vCalA=function(){
 if(!D.emps.length)return '<section class="c"><h2>Employee attendance</h2><p class="mu">Add an employee in People to see their calendar and check-in/out records.</p></section>';
 const employee=emp(CE)||D.emps[0];CE=employee.id;
 const days=new Date(Number(PM.slice(0,4)),Number(PM.slice(5)),0).getDate();
 const options=D.emps.map(e=>'<option value="'+e.id+'"'+(e.id===CE?' selected':'')+'>'+E(e.name)+' ('+E(e.code)+')</option>').join('');
 let detail='';
 for(let n=1;n<=days;n++){
  const date=PM+'-'+String(n).padStart(2,'0');if(date>today()||employee.doj&&date<employee.doj||employee.exit&&date>employee.exit)continue;
  const status=dstat(employee,date),a=D.att[employee.id+'|'+date]||{},labels={P:'Present',A:'Absent',L:'Leave',W:'Weekly off',H:'Holiday'},key=employee.id+'|'+date;
  let hours='—';if(a.in&&a.out){const start=a.in.split(':').map(Number),end=a.out.split(':').map(Number),mins=Math.max(0,end[0]*60+end[1]-start[0]*60-start[1]);hours=Math.floor(mins/60)+'h '+mins%60+'m'}
  detail+='<tr><td>'+E(fmtI(date))+'</td><td>'+E(new Date(date+'T12:00:00Z').toLocaleDateString('en-IN',{weekday:'long',timeZone:'UTC'}))+'</td><td><span class="attendance-status s'+E(status.s||'')+'">'+E(labels[status.s]||'Not checked in')+'</span></td><td>'+E(a.in||'—')+'</td><td>'+E(a.out||'—')+'</td><td>'+hours+'</td><td>'+(a.in?(late(a)?'<span class="no">Late</span>':'<span class="ok">On time</span>'):'—')+'</td><td>'+E(D.manualAttendance?.[key]?'Manual status correction':a.in&&!a.out?'Check-out pending':a.site||(a.dev?'Device':a.reg?'Correction request':a.in?'Office':''))+(a.pi?' <button onclick="selV(\''+key+'\',\'in\')">View in photo</button>':'')+(a.po?' <button onclick="selV(\''+key+'\',\'out\')">View out photo</button>':'')+'</td></tr>';
 }
 const headers=Array.from({length:days},(_,i)=>'<th>'+String(i+1).padStart(2,'0')+'</th>').join('');
 const muster=D.emps.map(e=>'<tr><td>'+E(e.name)+'</td>'+Array.from({length:days},(_,i)=>{const date=PM+'-'+String(i+1).padStart(2,'0'),s=dstat(e,date);return '<td class="'+(s.s?'s'+s.s:'')+'" title="'+E(date+' · '+(s.t||'Not recorded'))+'">'+E(s.s||'')+'</td>'}).join('')+'</tr>').join('');
 return '<section class="c attendance-controls"><div class="attendance-filters"><div><label for="attendance-employee">Staff</label><select id="attendance-employee" onchange="CE=Number(this.value);draw()">'+options+'</select></div><div><label for="attendance-month">Month</label><input id="attendance-month" type="month" value="'+PM+'" max="'+today().slice(0,7)+'" onchange="PM=this.value;draw()"></div></div></section>'+calCard(employee)+'<section class="c"><div class="attendance-register-heading"><div><h2>Detailed attendance · '+E(employee.name)+'</h2><p class="mu">Daily status, time in, time out and total working hours for '+E(PM)+'.</p></div><span class="chip">'+E(employee.code)+'</span></div><div class="w"><table class="attendance-detail"><thead><tr><th>Date</th><th>Day</th><th>Status</th><th>Time in</th><th>Time out</th><th>Working hours</th><th>Punctuality</th><th>Notes</th></tr></thead><tbody>'+(detail||'<tr><td colspan="8" class="mu">No completed dates within this employee’s employment period.</td></tr>')+'</tbody></table></div></section><section class="c"><h2>Muster roll · All employees</h2><div class="w"><table class="mt attendance-muster"><tr><th>Staff</th>'+headers+'</tr>'+muster+'</table></div><p class="mu">P = Present · A = Absent · L = Leave · W = Weekly off · H = Holiday</p></section>'+regAdmin();
};
})();
