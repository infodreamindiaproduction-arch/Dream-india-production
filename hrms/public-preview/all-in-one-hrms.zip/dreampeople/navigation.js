/* Keep navigation in place after the complete page (including extensions) renders. */
(function () {
    'use strict';
    const render = window.draw;
    const sessionKey = () => !ses ? '' : ses.r + ':' + (ses.id || '');
    let renderedSession = sessionKey();

    window.draw = function (...args) {
        const sidebar = document.querySelector('#app .sb');
        const active = document.activeElement;
        const position = sidebar && renderedSession === sessionKey() ? {
            x: window.scrollX,
            y: window.scrollY,
            left: sidebar.scrollLeft,
            top: sidebar.scrollTop,
            focusedTab: sidebar.contains(active) && active.matches('.mi') ? active.textContent : null
        } : null;

        const result = render.apply(this, args);
        renderedSession = sessionKey();
        const nextSidebar = document.querySelector('#app .sb');
        if (position && nextSidebar) {
            // Restore after all custom menus have been added, so offsets are not clamped early.
            nextSidebar.scrollTo({left: position.left, top: position.top, behavior: 'instant'});
            if (position.focusedTab !== null) {
                const nextTab = [...nextSidebar.querySelectorAll('.mi')]
                    .find(button => button.textContent === position.focusedTab);
                nextTab?.focus({preventScroll: true});
            }
            window.scrollTo({left: position.x, top: position.y, behavior: 'instant'});
        }
        return result;
    };
})();
