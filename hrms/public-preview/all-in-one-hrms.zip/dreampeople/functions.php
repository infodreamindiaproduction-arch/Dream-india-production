<?php
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/inc/companies.php';
require_once __DIR__ . '/inc/api.php';
require_once __DIR__ . '/inc/reference.php';
require_once __DIR__ . '/inc/coupons.php';
require_once __DIR__ . '/inc/accounts.php';
require_once __DIR__ . '/inc/employee.php';
require_once __DIR__ . '/inc/public.php';
require_once __DIR__ . '/inc/header-clock.php';
function dp_setup_roles() {
    $admin=get_role('administrator');if($admin)$admin->add_cap('manage_dreampeople');
    add_role('dreampeople_hr_manager','HR Manager',array('read'=>true,'manage_dreampeople'=>true));
    if(!get_option('dreampeople_initialized_v2')) { add_option('dreampeople_state_v2',array('revision'=>0,'data'=>dp_empty_state()),'',false);update_option('dreampeople_initialized_v2',1,false); }
}
add_action('after_switch_theme','dp_setup_roles');
add_action('after_setup_theme',function(){add_theme_support('title-tag');});
add_action('wp_enqueue_scripts',function(){if(!dip_is_portal_request()){
    wp_enqueue_style('dreampeople-sales',get_template_directory_uri().'/sales.css',array(),'7.2.0');
    wp_enqueue_script('dreampeople-sales',get_template_directory_uri().'/sales.js',array(),'7.2.0',true);
    wp_add_inline_script('dreampeople-sales','window.HRMSSales='.wp_json_encode(array('api'=>rest_url('dreampeople/v1/sales/enquiry'),'nonce'=>wp_create_nonce('hrms_sales_enquiry'),'restNonce'=>wp_create_nonce('wp_rest'))).';','before');return;
}if(!dip_company_view_access(dip_company_id()))return;
    wp_enqueue_style('dreampeople',get_stylesheet_uri(),array(),'7.2.0');
    wp_enqueue_style('dreampeople-white-label',get_template_directory_uri().'/white-label.css',array('dreampeople'),'7.2.0');
    wp_enqueue_style('dreampeople-history',get_template_directory_uri().'/history.css',array('dreampeople-white-label'),'7.2.0');
    wp_enqueue_script('dreampeople-brand',get_template_directory_uri().'/brand-core.js',array(),'7.2.0',true);
    wp_enqueue_script('hrms-pdfmake',get_template_directory_uri().'/vendor/pdfmake.min.js',array(),'0.3.13',true);
    wp_enqueue_script('hrms-exceljs',get_template_directory_uri().'/vendor/exceljs.min.js',array(),'4.4.0',true);
    wp_enqueue_script('hrms-export-fonts',get_template_directory_uri().'/export-fonts.js',array('hrms-pdfmake'),'7.2.0',true);
    wp_enqueue_script('hrms-export-core',get_template_directory_uri().'/export-core.js',array('dreampeople-engine'),'7.2.0',true);
    wp_enqueue_script('hrms-export-files',get_template_directory_uri().'/export-files.js',array('hrms-pdfmake','hrms-exceljs','hrms-export-fonts'),'7.2.0',true);
    wp_enqueue_style('dreampeople-company',get_template_directory_uri().'/company.css',array('dreampeople-history'),'7.2.0');
    wp_enqueue_style('dreampeople-portal',get_template_directory_uri().'/portal.css',array('dreampeople-company'),'7.2.0');
    wp_enqueue_script('dreampeople-ai',get_template_directory_uri().'/ai-tools.js',array('dreampeople-brand'),'7.2.0',true);
    wp_enqueue_script('dreampeople-company-core',get_template_directory_uri().'/company-core.js',array('dreampeople-brand'),'7.2.0',true);
    wp_enqueue_script('dreampeople-engine',get_template_directory_uri().'/reference-engine.js',array(),'7.2.0',true);
    wp_enqueue_script('dreampeople-history-core',get_template_directory_uri().'/attendance-core.js',array('dreampeople-engine'),'7.2.0',true);
    wp_enqueue_script('dreampeople-reference',get_template_directory_uri().'/app.js',array('dreampeople-engine','dreampeople-brand','dreampeople-history-core','dreampeople-company-core','dreampeople-ai'),'7.2.0',true);
    wp_add_inline_script('dreampeople-reference','window.DREAMPEOPLE='.wp_json_encode(array('api'=>rest_url('dreampeople/v1/'),'nonce'=>wp_create_nonce('wp_rest'),'profile'=>admin_url('profile.php'),'logout'=>wp_logout_url(home_url('/')),'login'=>wp_login_url(home_url('/')),'mode'=>dip_company_role(dip_company_id())==='employee'?'employee':'manager','employeeId'=>dip_employee_id(),'themeKey'=>dip_company_role(dip_company_id())==='employee'?(string)dip_employee_id():'user_'.get_current_user_id(),'canBrand'=>dip_company_can_brand(),'companyId'=>dip_company_id(),'canCreateCompany'=>current_user_can('manage_options'),'salesUrl'=>dip_public_url(),'publicPages'=>array('privacy'=>dip_public_url('privacy'),'terms'=>dip_public_url('terms'),'refund'=>dip_public_url('refund'),'about'=>dip_public_url('about')))).';','before');
    wp_enqueue_script('dreampeople-meetings',get_template_directory_uri().'/meetings-ui.js',array('dreampeople-reference'),'7.2.0',true);
    wp_enqueue_script('dreampeople-attendance',get_template_directory_uri().'/attendance-ui.js',array('dreampeople-reference'),'7.2.0',true);
    wp_enqueue_script('dreampeople-adapter',get_template_directory_uri().'/reference-adapter.js',array('dreampeople-reference','dreampeople-meetings','dreampeople-attendance'),'7.2.0',true);
    wp_enqueue_script('dreampeople-white-label',get_template_directory_uri().'/white-label.js',array('dreampeople-adapter','dreampeople-brand'),'7.2.0',true);
    wp_enqueue_script('dreampeople-history',get_template_directory_uri().'/history-ui.js',array('dreampeople-white-label','dreampeople-history-core'),'7.2.0',true);
    wp_enqueue_script('dreampeople-companies',get_template_directory_uri().'/company-ui.js',array('dreampeople-history','dreampeople-company-core'),'7.2.0',true);
    wp_enqueue_script('hrms-exports',get_template_directory_uri().'/exports-ui.js',array('dreampeople-companies','hrms-export-core','hrms-export-files'),'7.2.0',true);
    wp_enqueue_script('dreampeople-actions',get_template_directory_uri().'/actions.js',array('hrms-exports'),'7.2.0',true);
    wp_enqueue_script('dreampeople-public-links',get_template_directory_uri().'/public-links.js',array('dreampeople-actions'),'7.2.0',true);
    wp_enqueue_script('dreampeople-language',get_template_directory_uri().'/localization.js',array('dreampeople-public-links'),'7.2.0',true);
    wp_enqueue_script('dreampeople-navigation',get_template_directory_uri().'/navigation.js',array('dreampeople-language','hrms-header-clock'),'7.2.0',true);
});
add_action('template_redirect',function(){
    if(!dip_is_portal_request()){nocache_headers();return;}
    if(!is_user_logged_in())auth_redirect();
    if(!dip_company_view_access(dip_company_id()))wp_die(esc_html__('Your account does not have HR workspace access. Ask an administrator to assign the HR Manager role.','dreampeople'),esc_html__('Access denied','dreampeople'),array('response'=>403));
    nocache_headers();header('Cache-Control: private, no-store, max-age=0');header('X-Robots-Tag: noindex, nofollow',true);
});
add_action('init',function(){if((int)get_option('dreampeople_roles_version')!==2){dp_setup_roles();update_option('dreampeople_roles_version',2,false);}});
add_filter('show_admin_bar',function($show){return is_admin()?$show:false;});
