<?php
if (!defined('ABSPATH')) { exit; }

function dip_is_hrms_login_user($user) {
    return $user instanceof WP_User && (
        user_can($user, 'hrms_employee') ||
        user_can($user, 'manage_dreampeople') ||
        user_can($user, 'manage_options')
    );
}

add_filter('login_redirect', function ($redirect, $requested, $user) {
    if (!dip_is_hrms_login_user($user)) { return $redirect; }

    // Super Admin can still explicitly open WordPress administration.
    if (user_can($user, 'manage_options') && $requested !== '') { return $redirect; }

    // Preserve the explicit own-profile route used to change a password.
    if ($requested !== '' && strtok($requested, '?') === admin_url('profile.php')) {
        return admin_url('profile.php');
    }

    return dip_portal_url();
}, 20, 3);

add_action('admin_init', function () {
    if (!is_user_logged_in() || current_user_can('manage_options') || wp_doing_ajax()) { return; }
    if (!dip_is_hrms_login_user(wp_get_current_user())) { return; }

    global $pagenow;
    if (in_array($pagenow, array('profile.php', 'admin-post.php'), true)) { return; }

    // Bookmarks and an existing WordPress Dashboard session also enter HRMS.
    wp_safe_redirect(dip_portal_url());
    exit;
});
