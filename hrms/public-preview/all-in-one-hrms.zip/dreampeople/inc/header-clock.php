<?php
if (!defined('ABSPATH')) { exit; }
add_action('wp_enqueue_scripts', function () {
    if (!dip_is_portal_request() || !dip_company_view_access(dip_company_id())) { return; }
    wp_enqueue_style('hrms-header-clock', get_template_directory_uri() . '/header-clock.css', array('dreampeople-portal'), '7.2.1');
    wp_enqueue_script('hrms-header-clock', get_template_directory_uri() . '/header-clock.js', array('dreampeople-language'), '7.2.1', true);
}, 20);
