<?php
if (!defined('ABSPATH')) exit;
function dip_company_tables(){global $wpdb;return array($wpdb->prefix.'hrms_companies',$wpdb->prefix.'hrms_members');}
function dip_company_install(){if((int)get_option('hrms_company_schema')===4)return;global $wpdb;list($c,$m)=dip_company_tables();require_once ABSPATH.'wp-admin/includes/upgrade.php';$charset=$wpdb->get_charset_collate();dbDelta("CREATE TABLE $c (
 id bigint unsigned NOT NULL AUTO_INCREMENT,
 name varchar(120) NOT NULL,
 created_by bigint unsigned NOT NULL,
 created_at datetime NOT NULL,
 PRIMARY KEY  (id)
) $charset;");dbDelta("CREATE TABLE $m (
 company_id bigint unsigned NOT NULL,
 user_id bigint unsigned NOT NULL,
 role varchar(20) NOT NULL,
 employee_id bigint unsigned DEFAULT NULL,
 PRIMARY KEY  (company_id,user_id),
 KEY user_id (user_id),
 UNIQUE KEY company_employee (company_id,employee_id)
) $charset;");$w=get_option('dreampeople_reference_v3');$name=$w['data']['co']['name']??get_bloginfo('name');$wpdb->query($wpdb->prepare("INSERT IGNORE INTO $c (id,name,created_by,created_at) VALUES(1,%s,0,%s)",$name,gmdate('Y-m-d H:i:s')));if(!get_option('hrms_company_schema'))foreach(get_users(array('role__in'=>array('administrator','dreampeople_hr_manager'),'fields'=>'all'))as $u)$wpdb->replace($m,array('company_id'=>1,'user_id'=>$u->ID,'role'=>user_can($u,'manage_options')?'owner':'manager'),array('%d','%d','%s'));if($wpdb->get_var("SHOW COLUMNS FROM $m LIKE 'employee_id'"))update_option('hrms_company_schema',4,false);}
add_action('init','dip_company_install',5);
function dip_company_role($id,$uid=null){$uid=$uid??get_current_user_id();if(!$uid)return null;if(user_can($uid,'manage_options'))return 'owner';global $wpdb;list($c,$m)=dip_company_tables();return $wpdb->get_var($wpdb->prepare("SELECT role FROM $m WHERE company_id=%d AND user_id=%d",$id,$uid));}
function dip_company_exists($id){global $wpdb;list($c)=dip_company_tables();return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM $c WHERE id=%d",$id));}
function dip_company_access($id){return $id>0&&dip_company_exists($id)&&(current_user_can('manage_dreampeople')||current_user_can('manage_options'))&&in_array(dip_company_role($id),array('owner','manager'),true);}
function dip_company_list(){global $wpdb;list($c,$m)=dip_company_tables();if(current_user_can('manage_options'))return $wpdb->get_results("SELECT id,name FROM $c ORDER BY id",ARRAY_A);return $wpdb->get_results($wpdb->prepare("SELECT c.id,c.name FROM $c c INNER JOIN $m m ON c.id=m.company_id WHERE m.user_id=%d ORDER BY c.id",get_current_user_id()),ARRAY_A);}
function dip_company_id(){if(isset($GLOBALS['hrms_request_company']))return $GLOBALS['hrms_request_company'];$header=$_SERVER['HTTP_X_HRMS_COMPANY']??null;if($header!==null){return preg_match('/^[1-9][0-9]*$/D',(string)$header)?(int)$header:0;}if(!is_user_logged_in())return 1;$id=(int)get_user_meta(get_current_user_id(),'hrms_active_company',true);if($id&&dip_company_view_access($id))return $id;$list=dip_company_list();return $list?(int)$list[0]['id']:0;}
function dip_company_option($key){$id=dip_company_id();if($id<1)throw new RuntimeException('No company selected');return $id===1?$key:$key.'_c'.$id;}
function dip_company_can_brand(){return dip_company_access(dip_company_id())&&dip_company_role(dip_company_id())==='owner';}
function dip_company_name(){global $wpdb;list($c)=dip_company_tables();return $wpdb->get_var($wpdb->prepare("SELECT name FROM $c WHERE id=%d",dip_company_id()))?:'Your Company';}
function dip_company_sync_name($data){if(empty($data['co']['name']))return;global $wpdb;list($c)=dip_company_tables();$wpdb->update($c,array('name'=>$data['co']['name']),array('id'=>dip_company_id()),array('%s'),array('%d'));}
function dip_company_document_key($key){return 'dreampeople_private_doc_'.hash('sha256',(dip_company_id()===1?'':dip_company_id().'|').$key);}
function dip_company_auth(){return current_user_can('manage_options')||current_user_can('manage_dreampeople')||current_user_can('hrms_employee');}
function dip_company_view_access($id){return dip_company_access($id)||($id>0&&dip_company_exists($id)&&current_user_can('hrms_employee')&&dip_company_role($id)==='employee');}
function dip_employee_id(){global $wpdb;list($c,$m)=dip_company_tables();return (int)$wpdb->get_var($wpdb->prepare("SELECT employee_id FROM $m WHERE company_id=%d AND user_id=%d AND role='employee'",dip_company_id(),get_current_user_id()));}
add_action('rest_api_init',function(){
 register_rest_route('dreampeople/v1','/companies',array(array('methods'=>'GET','permission_callback'=>'dip_company_auth','callback'=>function(){return array('companies'=>dip_company_list(),'active'=>dip_company_id(),'canCreate'=>current_user_can('manage_options'));}),array('methods'=>'POST','permission_callback'=>function(){return current_user_can('manage_options');},'callback'=>function($r){$name=trim(sanitize_text_field($r->get_param('name')??''));if(!$name||strlen($name)>300)return new WP_Error('company_name','Enter a company name under 100 characters',array('status'=>422));global $wpdb;list($c,$m)=dip_company_tables();$wpdb->insert($c,array('name'=>$name,'created_by'=>get_current_user_id(),'created_at'=>gmdate('Y-m-d H:i:s')),array('%s','%d','%s'));$id=(int)$wpdb->insert_id;if(!$id)return new WP_Error('company_create','Company could not be created',array('status'=>500));$wpdb->insert($m,array('company_id'=>$id,'user_id'=>get_current_user_id(),'role'=>'owner'),array('%d','%d','%s'));return array('id'=>$id,'name'=>$name);})));
 register_rest_route('dreampeople/v1','/companies/active',array('methods'=>'POST','permission_callback'=>'dip_company_auth','callback'=>function($r){$id=$r->get_param('company');if(!is_int($id)||!dip_company_view_access($id))return new WP_Error('company_denied','You do not have access to that company',array('status'=>403));update_user_meta(get_current_user_id(),'hrms_active_company',$id);return array('active'=>$id);}));
 register_rest_route('dreampeople/v1','/companies/members',array(array('methods'=>'GET','permission_callback'=>'dip_company_can_brand','callback'=>function(){global $wpdb;list($c,$m)=dip_company_tables();return $wpdb->get_results($wpdb->prepare("SELECT m.user_id,m.role,u.display_name,u.user_email FROM $m m INNER JOIN {$wpdb->users} u ON u.ID=m.user_id WHERE m.company_id=%d ORDER BY m.user_id",dip_company_id()),ARRAY_A);}),array('methods'=>'POST','permission_callback'=>'dip_company_can_brand','callback'=>function($r){$login=sanitize_text_field($r->get_param('account')??'');$role=$r->get_param('role');$u=get_user_by(is_email($login)?'email':'login',$login);if(!$u||!user_can($u,'manage_dreampeople')||!in_array($role,array('owner','manager'),true))return new WP_Error('member_invalid','Use an existing WordPress HR Manager account and a valid role',array('status'=>422));global $wpdb;list($c,$m)=dip_company_tables();$id=dip_company_id();$before=$wpdb->get_var($wpdb->prepare("SELECT role FROM $m WHERE company_id=%d AND user_id=%d",$id,$u->ID));if($before==='owner'&&$role!=='owner'&&(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $m WHERE company_id=%d AND role='owner'",$id))<=1)return new WP_Error('last_owner','Keep at least one company owner',array('status'=>422));$wpdb->replace($m,array('company_id'=>$id,'user_id'=>$u->ID,'role'=>$role),array('%d','%d','%s'));return array('saved'=>true);})));
});
