<?php
if (!defined('ABSPATH')) { exit; }
function dip_reference_calc($data,$employee,$month) {
    $cfg=$data['cfg'];$dm=(int)gmdate('t',strtotime($month.'-01T12:00:00Z'));$pr=0;$paid=0;$unmarked=0;$unpaid=0;$today=dp_today();
    for($day=1;$day<=$dm;$day++){
        $date=$month.'-'.str_pad((string)$day,2,'0',STR_PAD_LEFT);
        if((!empty($employee['doj'])&&$date<$employee['doj'])||(!empty($employee['exit'])&&$date>$employee['exit'])||$date>$today)continue;
        $a=$data['att'][$employee['id'].'|'.$date]??array();$hours=null;
        if(!empty($a['in'])&&!empty($a['out'])){$x=explode(':',$a['in']);$y=explode(':',$a['out']);$hours=max(0,((int)$y[0]*60+(int)$y[1]-(int)$x[0]*60-(int)$x[1])/60);}
        $part=!empty($cfg['half'])&&$hours!==null&&$hours<$cfg['half']?.5:1;$leave=null;
        foreach($data['leaves']??array()as $q)if($q['eid']==$employee['id']&&$q['st']==='approved'&&$q['from']<=$date&&$q['to']>=$date){$leave=$q;break;}
        $holiday=false;foreach($data['ann']??array()as $q)if(($q['cat']??'')==='Holiday'&&($q['hd']??'')===$date)$holiday=true;
        $off=!empty($cfg['paySun'])&&(int)gmdate('w',strtotime($date.'T12:00:00Z'))===0;
        $manual=$data['manualAttendance'][$employee['id'].'|'.$date]??null;
        if($manual){if($manual['status']==='Present'){$pr++;$paid++;}else $unpaid++;continue;}
        if(!empty($a['in']))$pr+=$part;
        if($leave){if($leave['type']!=='LWP')$paid++;else $unpaid++;}
        elseif(!empty($a['in'])){$paid+=$part;$unpaid+=1-$part;}
        elseif($off||$holiday)$paid++;else{$unmarked++;$unpaid++;}
    }
    $r=$paid/$dm;$b=(int)round(($employee['basic']??0)*$r);$h=(int)round(($employee['hra']??0)*$r);$o=(int)round(($employee['oth']??0)*$r);$g=$b+$h+$o;
    $full=($employee['basic']??0)+($employee['hra']??0)+($employee['oth']??0);$pfw=!empty($cfg['pfCap'])?min($b,15000):$b;
    $pfE=($employee['pf']??true)?(int)round($pfw*($cfg['pfE']??0)/100):0;$pfR=($employee['pf']??true)?$pfE+(int)round(min($pfw,15000)*.01):0;
    $adj=$data['adj'][$month][$employee['id']]??array();$inc=$adj['inc']??0;$ad=$adj['ad']??0;$eligible=($employee['esi']??true)&&$full<=($cfg['esiLim']??0);
    $esE=$eligible?(int)ceil(($g+$inc)*($cfg['esE']??0)/100):0;$esR=$eligible?(int)ceil(($g+$inc)*($cfg['esR']??0)/100):0;$pt=$employee['pt']??0;$td=$employee['tds']??0;$rbo=0;
    foreach($data['reim']??array()as $q)if($q['eid']==$employee['id']&&$q['st']==='approved'&&substr($q['d'],0,7)===$month)$rbo+=$q['amt'];
    $e=$employee;unset($e['ph']);return array('e'=>$e,'pr'=>$pr,'paid'=>$paid,'dm'=>$dm,'b'=>$b,'h'=>$h,'o'=>$o,'g'=>$g,'pfE'=>$pfE,'pfR'=>$pfR,'esE'=>$esE,'esR'=>$esR,'pt'=>$pt,'td'=>$td,'inc'=>$inc,'ad'=>$ad,'rbo'=>$rbo,'ptd'=>$pt+$td+$ad,'rb'=>$rbo+$inc,'net'=>$g+$rbo+$inc-$pfE-$esE-$pt-$td-$ad,'unmarked'=>$unmarked,'unpaid'=>$unpaid);
}
