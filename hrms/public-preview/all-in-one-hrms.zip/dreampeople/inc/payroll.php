<?php
if (!defined('ABSPATH')) { exit; }
function dp_today() { return (new DateTimeImmutable('now', new DateTimeZone('Asia/Kolkata')))->format('Y-m-d'); }
function dp_attendance_status($s, $e, $date) {
    if ($date < $e['joined'] || (!empty($e['exit']) && $date > $e['exit'])) return 'Not employed';
    foreach ($s['leaves'] as $l) if ($l['employee'] === $e['id'] && $l['status'] === 'Approved' && $l['start'] <= $date && $l['end'] >= $date) return $l['type'] === 'Unpaid leave' ? 'Unpaid leave' : 'Paid leave';
    if (isset($s['attendance'][$date][$e['id']])) return $s['attendance'][$date][$e['id']]['status'];
    foreach ($s['settings']['holidays'] as $h) if ($h['date'] === $date) return 'Holiday';
    if (in_array((int)gmdate('w', strtotime($date . 'T12:00:00Z')), $s['settings']['weekOff'], true)) return 'Weekly off';
    return 'Unmarked';
}
function dp_payroll($s, $month) {
    $days = (int)gmdate('t', strtotime($month . '-01T12:00:00Z')); $rows = array();
    foreach ($s['employees'] as $e) {
        if ($e['joined'] > $month . '-' . $days || (!empty($e['exit']) && $e['exit'] < $month . '-01')) continue;
        $paid = 0; $unpaid = 0; $unmarked = 0; $ot = 0;
        for ($d = 1; $d <= $days; $d++) {
            $date = $month . '-' . str_pad((string)$d, 2, '0', STR_PAD_LEFT); $status = dp_attendance_status($s, $e, $date);
            if ($status === 'Not employed') continue;
            if (in_array($status, array('Present','Late','Paid leave','Weekly off','Holiday'), true)) $paid++;
            elseif ($status === 'Half day') { $paid += .5; $unpaid += .5; }
            elseif (in_array($status, array('Absent','Unpaid leave'), true)) $unpaid++; else $unmarked++;
            $ot += $s['attendance'][$date][$e['id']]['overtime'] ?? 0;
        }
        $adj = array(); foreach ($s['adjustments'] as $a) if ($a['employee'] === $e['id'] && $a['month'] === $month) $adj = $a;
        $base = $e['basic'] + $e['hra'] + $e['allowance']; $basic = (int)round($e['basic'] * $paid / $days); $earned = (int)round($base * $paid / $days);
        $overtime = (int)round($ot / 60 * $base / $days / $s['settings']['shiftHours'] * $s['settings']['overtimeMultiplier']);
        $bonus = $adj['bonus'] ?? 0; $gross = $earned + $overtime + $bonus;
        $pf = $e['pf'] ? (int)round(min($basic, $s['settings']['pfCap']) * $s['settings']['pfPercent'] / 100) : 0;
        $esi = $e['esi'] && $base <= $s['settings']['esiCeiling'] ? (int)round($gross * $s['settings']['esiPercent'] / 100) : 0;
        $tds = $adj['tds'] ?? 0; $advance = $adj['advance'] ?? 0; $other = $adj['other'] ?? 0; $pt = $adj['pt'] ?? 0;
        $deductions = $pf + $esi + $tds + $advance + $other + $pt;
        $rows[] = array('employee'=>$e['id'],'name'=>$e['name'],'code'=>$e['code'],'department'=>$e['department'],'designation'=>$e['designation'],'base'=>$base,'days'=>$days,'paid'=>$paid,'unpaid'=>$unpaid,'unmarked'=>$unmarked,'basic'=>$basic,'earned'=>$earned,'overtime'=>$overtime,'bonus'=>$bonus,'gross'=>$gross,'pf'=>$pf,'esi'=>$esi,'tds'=>$tds,'advance'=>$advance,'other'=>$other,'pt'=>$pt,'deductions'=>$deductions,'net'=>$gross-$deductions,'lop'=>$base-$earned);
    }
    return $rows;
}
