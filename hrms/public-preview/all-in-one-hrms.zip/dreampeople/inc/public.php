<?php
if(!defined('ABSPATH'))exit;
function dip_portal_url(){return add_query_arg('hrms_portal','1',home_url('/'));}
function dip_is_portal_request(){return isset($_GET['hrms_portal'])&&$_GET['hrms_portal']==='1';}
function dip_public_url($page=''){return $page?add_query_arg('hrms_page',$page,home_url('/')):home_url('/');}
function dip_public_content(){return json_decode(file_get_contents(__DIR__.'/../public/content.json'),true);}
function dip_public_legal_html($key){$pages=dip_public_content();$page=$pages[$key]??$pages['about'];$html='<article class="sales-legal"><span class="sales-eyebrow">DREAM INDIA PRODUCTION</span><h1>'.esc_html($page['title']).'</h1><p>'.esc_html($page['intro']).'</p>';foreach($page['sections']as $section)$html.='<section><h2>'.esc_html($section['title']).'</h2><p>'.esc_html($section['text']).'</p></section>';return $html.'</article>';}
function dip_public_brand(){
    $primary=get_option('dreampeople_reference_v3',array());$brand=dip_brand_validate($primary['data']['brand']??dip_brand_defaults());
    // The reseller's marketing identity is independent from the currently selected client.
    return array('name'=>'All in One HRMS','logo'=>$brand['logo']?:'data:image/svg+xml;base64,'.base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#16844a"/><text x="32" y="41" text-anchor="middle" fill="white" font-family="Arial" font-size="27" font-weight="700">DI</text></svg>'));
}
function dip_public_price_cards(){
    $prices=dip_pricing();$html='';foreach(array('monthly'=>array('Monthly','per month'),'quarterly'=>array('Quarterly','per quarter'),'annually'=>array('Annually','per year'))as $key=>$plan){$html.='<article class="sales-price-card'.($key==='quarterly'?' featured':'').'">'.($key==='quarterly'?'<span class="sales-price-badge">QUARTERLY PLAN</span>':'').'<h3>'.$plan[0].'</h3><div class="sales-price">₹'.esc_html(number_format($prices[$key]/100,($prices[$key]%100)?2:0)).'</div><p>'.$plan[1].'</p><ul><li>Attendance & employee records</li><li>Payroll & payslip workflows</li><li>Company and employee portals</li><li>Setup scope confirmed on enquiry</li></ul><a href="#enquiry" data-sales-plan="'.$key.'">Enquire about '.$plan[0].' ↗</a></article>';}
    return $html;
}
function dip_render_public_page(){
    $pages=dip_public_content();$key=isset($_GET['hrms_page'])&&is_string($_GET['hrms_page'])?sanitize_key($_GET['hrms_page']):'';if($key&&!isset($pages[$key])){status_header(404);$key='about';}
    $brand=dip_public_brand();$vars=array('{{TITLE}}'=>esc_html(($key?$pages[$key]['title'].' · ':'').'All in One HRMS'),'{{BRAND}}'=>esc_html($brand['name']),'{{LOGO}}'=>esc_attr($brand['logo']),'{{HOME}}'=>esc_url(dip_public_url()),'{{LOGIN}}'=>esc_url(wp_login_url(dip_portal_url())),'{{PRICING_CARDS}}'=>dip_public_price_cards(),'{{YEAR}}'=>gmdate('Y'),'{{STYLES}}'=>'','{{SCRIPTS}}'=>'');
    foreach(array('privacy','terms','refund','about')as $page)$vars['{{'.strtoupper($page).'}}']=esc_url(dip_public_url($page));
    $vars['{{CONTENT}}']=$key?dip_public_legal_html($key):strtr(file_get_contents(__DIR__.'/../public/sales-content.html'),$vars);
    remove_action('wp_head','_wp_render_title_tag',1);ob_start();wp_head();$vars['{{WP_HEAD}}']=ob_get_clean();ob_start();wp_footer();$vars['{{WP_FOOTER}}']=ob_get_clean();
    echo strtr(file_get_contents(__DIR__.'/../public/shell.html'),$vars);
}
add_action('init',function(){register_post_type('hrms_enquiry',array('label'=>'HRMS Enquiries','public'=>false,'publicly_queryable'=>false,'show_ui'=>current_user_can('manage_options'),'show_in_rest'=>false,'menu_icon'=>'dashicons-email-alt','supports'=>array('title','editor'),'capabilities'=>array('edit_posts'=>'manage_options','edit_others_posts'=>'manage_options','publish_posts'=>'manage_options','read_private_posts'=>'manage_options','delete_posts'=>'manage_options','edit_post'=>'manage_options','read_post'=>'manage_options','delete_post'=>'manage_options','create_posts'=>'do_not_allow'),'map_meta_cap'=>false));});
add_action('rest_api_init',function(){register_rest_route('dreampeople/v1','/sales/enquiry',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>function($r){
    if(strlen($r->get_body())>12000)return new WP_Error('enquiry_size','Your enquiry is too long.',array('status'=>413));$p=$r->get_json_params();
    if(!is_array($p)||!is_string($p['nonce']??null)||!wp_verify_nonce($p['nonce'],'hrms_sales_enquiry'))return new WP_Error('enquiry_nonce','Refresh the page and submit again.',array('status'=>403));
    if(!empty($p['website']))return new WP_Error('enquiry_spam','Please leave the website field empty.',array('status'=>422));
    foreach(array('name'=>100,'company'=>150,'email'=>150,'phone'=>30,'message'=>3000,'plan'=>20,'size'=>20)as $key=>$limit)if(!is_string($p[$key]??'')||strlen($p[$key]??'')>$limit)return new WP_Error('enquiry_field','Check the enquiry fields and try again.',array('status'=>422));
    $name=sanitize_text_field($p['name']??'');$company=sanitize_text_field($p['company']??'');$email=sanitize_email($p['email']??'');$phone=sanitize_text_field($p['phone']??'');$message=sanitize_textarea_field($p['message']??'');$plan=$p['plan']??'custom';$size=$p['size']??'';
    if(!$name||!$company||!is_email($email)||strlen($message)<10||($p['consent']??false)!==true||!in_array($plan,array('monthly','quarterly','annually','custom'),true)||!in_array($size,array('1-10','11-50','51-200','200+'),true)||($phone&&!preg_match('/^[+()0-9 .-]{3,30}$/D',$phone)))return new WP_Error('enquiry_invalid','Enter your name, company, valid email, requirements and privacy consent.',array('status'=>422));
    $rate='hrms_enquiry_rate_'.hash_hmac('sha256',$_SERVER['REMOTE_ADDR']??'unknown',wp_salt('nonce'));$count=(int)get_transient($rate);if($count>=5)return new WP_Error('enquiry_rate','Too many enquiries. Please try later or email us directly.',array('status'=>429));
    $body="HRMS enquiry\n\nName: $name\nCompany: $company\nEmail: $email\nPhone: $phone\nPlan: $plan\nTeam size: $size\n\nRequirements:\n$message\n\nPrivacy consent: accepted";
    $id=wp_insert_post(array('post_type'=>'hrms_enquiry','post_status'=>'private','post_title'=>$company.' · '.$name,'post_content'=>$body),true);if(is_wp_error($id))return new WP_Error('enquiry_save','Unable to save your enquiry. Please email us directly.',array('status'=>503));
    set_transient($rate,$count+1,HOUR_IN_SECONDS);$sent=wp_mail('productiondreamindia@gmail.com','HRMS enquiry: '.$company,$body,array('Content-Type: text/plain; charset=UTF-8','Reply-To: '.$email));update_post_meta($id,'_hrms_email_accepted',(bool)$sent);
    return array('emailSent'=>(bool)$sent,'message'=>$sent?'Your enquiry has been submitted. We will contact you using the details provided.':'Your enquiry was saved, but email delivery is unavailable. Please email productiondreamindia@gmail.com directly.');
}));});
add_action('login_footer',function(){echo '<p style="text-align:center;padding:15px;font-size:12px"><a href="'.esc_url(dip_public_url('privacy')).'">Privacy Policy</a> · <a href="'.esc_url(dip_public_url('terms')).'">Terms & Conditions</a> · <a href="'.esc_url(dip_public_url('refund')).'">Refund Policy</a> · <a href="'.esc_url(dip_public_url('about')).'">About Us</a></p>';});
