(function () {
  'use strict';
  var clockClass = 'hrms-live-clock';
  function updateClock(clock) {
    var now = new Date();
    var hindi = /^hi/i.test(document.documentElement.lang);
    var locale = hindi ? 'hi-IN' : 'en-IN';
    var time = clock.querySelector('time');
    time.dateTime = now.toISOString();
    time.textContent = new Intl.DateTimeFormat(locale, {
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
    }).format(now);
    clock.querySelector('small').textContent = new Intl.DateTimeFormat(locale, {
      weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'
    }).format(now);
    clock.title = hindi ? 'आपके डिवाइस का स्थानीय समय' : 'Your device’s local time';
  }
  function mountClock() {
    var header = document.querySelector('.top');
    if (!header || header.querySelector('.' + clockClass)) return;
    var clock = document.createElement('div');
    clock.className = clockClass;
    clock.setAttribute('role', 'timer');
    clock.setAttribute('aria-live', 'off');
    clock.setAttribute('data-i18n-ignore', '');
    clock.innerHTML = '<svg aria-hidden="true" width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span><time></time><small></small></span>';
    header.insertBefore(clock, header.lastElementChild);
    updateClock(clock);
  }
  if (typeof window.draw === 'function') {
    var draw = window.draw;
    window.draw = function () {
      var result = draw.apply(this, arguments);
      mountClock();
      return result;
    };
  }
  function refresh() {
    mountClock();
    document.querySelectorAll('.' + clockClass).forEach(updateClock);
  }
  refresh();
  setInterval(refresh, 1000);
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) refresh();
  });
})();
