/* Local-only PDF and XLSX writers. No report contents leave the browser. */
(function(root){'use strict';
const text=value=>String(value??''),money=value=>'₹ '+Number(value||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
const cleanName=value=>text(value).replace(/[\\/:*?"<>|\u0000-\u001f]/g,'-').replace(/\s+/g,'_').slice(0,140)||'HRMS_export';
function pdfSetup(){if(!root.pdfMake)throw Error('PDF exporter did not load. Refresh the page.');if(!root.HRMSExportFonts)throw Error('PDF fonts did not load. Refresh the page.');root.pdfMake.addVirtualFileSystem(root.HRMSExportFonts);root.pdfMake.addFonts({HRMS:{normal:'HRMS-Regular.ttf',bold:'HRMS-Bold.ttf',italics:'HRMS-Regular.ttf',bolditalics:'HRMS-Bold.ttf'}});return root.pdfMake}
async function workbook(reports,meta={}){
 if(!root.ExcelJS)throw Error('Excel exporter did not load. Refresh the page.');const book=new root.ExcelJS.Workbook();book.creator='All in One HRMS';book.created=new Date();book.modified=book.created;
 const info=book.addWorksheet('Export details');info.addRows([['All in One HRMS · Export'],['Company',meta.company||reports[0]?.company||''],['Generated (Asia/Kolkata)',new Date().toLocaleString('en-IN',{timeZone:'Asia/Kolkata'})],['Scope',meta.scope||'Selected records'],['Currency','INR'],['Notice','Payroll drafts are marked DRAFT. Credentials and biometric templates are excluded.']]);info.getColumn(1).width=30;info.getColumn(2).width=100;info.getRow(1).font={bold:true,size:15,color:{argb:'FF17344D'}};info.getColumn(2).alignment={wrapText:true,vertical:'top'};
 const names=new Set(['Export details']);
 for(const report of reports){let base=text(report.title).replace(/[\\/*?:\[\]]/g,' ').slice(0,31)||'Records',name=base,n=1;while(names.has(name))name=base.slice(0,26)+' '+(++n);names.add(name);const sheet=book.addWorksheet(name,{views:[{state:'frozen',ySplit:5}],pageSetup:{paperSize:9,orientation:'landscape',fitToPage:true,fitToWidth:1,fitToHeight:0}});
  sheet.addRow([report.title]);sheet.mergeCells(1,1,1,Math.max(1,report.headers.length));sheet.getRow(1).font={bold:true,size:15,color:{argb:'FF17344D'}};sheet.getRow(1).height=28;
  sheet.addRow(['Company',report.company||meta.company||'']);sheet.addRow(['Period',report.period||'All dates']);sheet.addRow([]);sheet.addRow(report.headers);
  const header=sheet.getRow(5);header.height=30;header.font={bold:true,color:{argb:'FFFFFFFF'}};header.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF17344D'}};header.alignment={wrapText:true,vertical:'middle'};
  report.headers.forEach((label,i)=>{sheet.getColumn(i+1).width=/notes|message|reason|agenda|comments|replies|achievements/i.test(label)?50:/employee|company|title|name/i.test(label)?26:/account|uan|esic|ifsc/i.test(label)?24:19});
  for(const row of report.rows){
   const added=sheet.addRow(row.map((value,i)=>report.types?.[i]==='number'&&value!==''?Number(value):text(value)));
   added.alignment={vertical:'top',wrapText:true};
   added.eachCell((cell,index)=>{cell.numFmt=report.types?.[index-1]==='number'?(/INR/.test(report.headers[index-1])?'"₹" #,##0.00':'0.##'):'@';cell.border={bottom:{style:'hair',color:{argb:'FFE1E8F0'}}};});
   if(added.number%2===0)added.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FFF4F8FB'}};
  }
  if(report.headers.length)sheet.autoFilter={from:{row:5,column:1},to:{row:5,column:report.headers.length}};
  sheet.pageSetup.printTitlesRow='5:5';
 }
 return new Blob([await book.xlsx.writeBuffer()],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
function basePdf(meta={}){return {pageSize:'A4',pageOrientation:'landscape',pageMargins:[32,40,32,40],defaultStyle:{font:'HRMS',fontSize:8,color:'#1c344a'},info:{title:meta.title||'HRMS records',author:meta.company||'All in One HRMS',creator:'All in One HRMS'},styles:{title:{fontSize:18,bold:true,color:'#17344d',margin:[0,0,0,6]},sub:{fontSize:8,color:'#61778b',margin:[0,0,0,14]},section:{fontSize:12,bold:true,color:'#17344d',margin:[0,12,0,8]},th:{bold:true,color:'#fff',fillColor:'#17344d',fontSize:8},small:{fontSize:7,color:'#61778b'}},footer:(page,pages)=>({columns:[{text:meta.company||'All in One HRMS',fontSize:7,color:'#718499'},{text:'All in One HRMS · '+page+' / '+pages,alignment:'right',fontSize:7,color:'#718499'}],margin:[32,13,32,0]})}}
const tableLayout={hLineColor:()=> '#dce5ed',vLineColor:()=> '#dce5ed',hLineWidth:()=>.5,vLineWidth:()=>.5,fillColor:row=>row>0&&row%2===0?'#f3f7fa':null,paddingLeft:()=>6,paddingRight:()=>6,paddingTop:()=>6,paddingBottom:()=>6};
function reportDefinition(reports,meta={}){
 const doc=basePdf(meta);doc.content=[{text:meta.title||'Company records',style:'title'},{text:(meta.company||reports[0]?.company||'')+' · '+(meta.scope||'Selected records')+'\nGenerated '+new Date().toLocaleString('en-IN',{timeZone:'Asia/Kolkata'})+' · INR',style:'sub'}];
 for(const report of reports){doc.content.push({text:report.title+' · '+(report.period||'All dates'),style:'section'});if(!report.rows.length){doc.content.push({text:'No records for this selection.',style:'sub'});continue}
  if(report.layout==='record'){report.rows.forEach((row,i)=>{doc.content.push({text:report.title+' · Record '+(i+1),bold:true,margin:[0,8,0,5]},{table:{widths:[150,'*'],body:row.map((value,index)=>[{text:report.headers[index],bold:true,fillColor:'#f1f5f9'},text(value)])},layout:tableLayout})});continue}
  const batches=[];if(report.headers.length<=10)batches.push(report.headers.map((_,i)=>i));else for(let start=2;start<report.headers.length;start+=8)batches.push([0,1,...Array.from({length:Math.min(8,report.headers.length-start)},(_,i)=>start+i)]);
  batches.forEach((indices,n)=>{if(batches.length>1)doc.content.push({text:'Columns '+(n+1)+' / '+batches.length+' · Employee identifiers repeat in each section',style:'small',margin:[0,6,0,5]});doc.content.push({table:{headerRows:1,dontBreakRows:false,widths:indices.map(()=>'*'),body:[indices.map(i=>({text:report.headers[i],style:'th'})),...report.rows.map(row=>indices.map(i=>text(row[i])))]},layout:tableLayout,margin:[0,0,0,12]})});
 }
 return doc;
}
async function imageData(value){if(!/^data:image\/(png|jpeg|webp);base64,/i.test(value||''))return null;if(!value.startsWith('data:image/webp'))return value;try{return await new Promise(resolve=>{const image=new Image();image.onload=()=>{const canvas=document.createElement('canvas');canvas.width=image.naturalWidth;canvas.height=image.naturalHeight;canvas.getContext('2d').drawImage(image,0,0);resolve(canvas.toDataURL('image/png'))};image.onerror=()=>resolve(null);image.src=value})}catch{return null}}
async function payslipDefinition(records,meta={}){
 const doc=basePdf(meta);doc.pageOrientation='portrait';doc.pageMargins=[30,30,30,35];doc.content=[];
 for(let index=0;index<records.length;index++){
  const record=records[index],s=record.snapshot,e=s.e||{},company=record.company||{},logo=await imageData(company.logo),stamp=await imageData(company.stamp),rows=(items)=>items.map(([label,value])=>[{text:label,margin:[0,3,0,3]},{text:money(value),alignment:'right',margin:[0,3,0,3]}]);
  const reimbursement=Number(s.rbo??Number(s.rb||0)-Number(s.inc||0)),earnings=Number(s.g||0)+Number(s.inc||0)+reimbursement,deductions=['pfE','esE','pt','td','ad'].reduce((sum,k)=>sum+Number(s[k]||0),0);
  const heading=[{stack:[{text:company.name||'Company',fontSize:20,bold:true,color:'#17344d'},{text:company.tag||'HR and Payroll',fontSize:9,color:'#718499',margin:[0,3,0,0]}],width:'*'},{text:[company.addr,company.gstin?'GSTIN: '+company.gstin:'',company.phone,company.email].filter(Boolean).join('\n'),alignment:'right',width:205,fontSize:8,color:'#61778b'}];if(logo)heading.unshift({image:logo,fit:[42,42],width:50});
  doc.content.push({columns:heading,pageBreak:index?'before':undefined,margin:[0,0,0,18]},{text:'PAYSLIP · '+record.month,fontSize:15,bold:true,alignment:'center',color:'#17344d',margin:[0,0,0,6]},{text:record.status+' · Revision '+record.version+(record.issuedAt?' · '+record.issuedAt:''),alignment:'center',bold:true,fontSize:9,color:record.status.startsWith('DRAFT')?'#b45309':'#15803d',margin:[0,0,0,16]});
  const details=[['Employee',e.name,'Employee code',e.code],['Department',e.dept,'Designation',e.des],['Date of joining',e.doj,'Pay period',record.month],['UAN',e.uan,'ESIC',e.esic],['Bank',e.bank,'Account number',e.acc],['IFSC',e.ifsc,'Account holder',e.ach||e.name]];
  doc.content.push({table:{widths:[85,'*',90,'*'],body:details.map(row=>row.map((v,i)=>({text:text(v)||'—',bold:i%2===0,fillColor:i%2===0?'#f4f7fa':null,margin:[0,2,0,2]})))},layout:tableLayout,margin:[0,0,0,15]},{table:{widths:['*','*','*','*'],body:[['Days in month','Present days','Paid days','Unpaid recorded days'].map(v=>({text:v,alignment:'center',fillColor:'#f0f6fb',fontSize:8})),[s.dm,s.pr,s.paid,s.unpaid??Number(s.dm)-Number(s.paid)].map(v=>({text:text(v),alignment:'center',bold:true,fontSize:13}))]},layout:tableLayout,margin:[0,0,0,15]});
  const earningRows=rows([['Basic + DA',s.b],['HRA',s.h],['Other allowance',s.o],['Incentive / bonus',s.inc],['Reimbursements',reimbursement]]),deductionRows=rows([['PF (employee)',s.pfE],['ESI (employee)',s.esE],['Professional tax',s.pt],['TDS',s.td],['Advance / loan recovery',s.ad]]);
  const side=(title,body,total)=>({width:'*',table:{widths:['*',70],body:[[{text:title,style:'th'},{text:'INR',style:'th',alignment:'right'}],...body,[{text:'Total',bold:true,fillColor:'#edf5f0'},{text:money(total),bold:true,alignment:'right',fillColor:'#edf5f0'}]]},layout:tableLayout});
  doc.content.push({columns:[side('Earnings',earningRows,earnings),{text:'',width:12},side('Deductions',deductionRows,deductions)],margin:[0,0,0,15]},{table:{widths:['*',160],body:[[{text:'NET PAY · TAKE HOME',bold:true,color:'#fff',fillColor:'#14834b',fontSize:11,margin:[0,7,0,7]},{text:money(s.net),bold:true,color:'#fff',fillColor:'#14834b',fontSize:15,alignment:'right',margin:[0,5,0,5]}]]},layout:'noBorders',margin:[0,0,0,12]},{text:'Employer contribution (not deducted): PF + EDLI '+money(s.pfR)+' · ESI '+money(s.esR),fontSize:8,color:'#61778b',margin:[0,0,0,10]});
  if(record.policySource==='legacy-current-policy')doc.content.push({text:'Revised using payroll rules captured during correction; original employee salary structure retained.',fontSize:8,color:'#8b6b3b',margin:[0,0,0,10]});
  if(record.note)doc.content.push({text:'Record note: '+record.note,fontSize:8,color:'#61778b',margin:[0,0,0,10]});
  doc.content.push({columns:[{text:'Employee acknowledgement',fontSize:8,color:'#718499',margin:[0,30,0,0]},stamp?{stack:[{image:stamp,fit:[55,55],alignment:'right'},{text:'Authorised signatory',fontSize:8,alignment:'right'}]}:{text:'Authorised signatory',fontSize:8,alignment:'right',margin:[0,30,0,0]}]});
 }
 return doc;
}
async function pdf(reports,meta={}){const definition=reports.length&&reports.every(r=>r.payslip)?await payslipDefinition(reports.map(r=>r.payslip),meta):reportDefinition(reports,meta);return await pdfSetup().createPdf(definition).getBlob()}
root.HRMSExportFiles={workbook,pdf,reportDefinition,payslipDefinition,cleanName};
})(typeof window!=='undefined'?window:globalThis);
